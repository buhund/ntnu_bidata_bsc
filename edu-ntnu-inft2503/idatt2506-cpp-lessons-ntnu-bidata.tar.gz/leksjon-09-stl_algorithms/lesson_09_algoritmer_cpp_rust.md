## INFT2503 - Algoritmer i nyere C++ og Rust



## Algoritmer i nyere C++

C++20 standarden fikk forbedre støtte for algoritmer gjennom et nytt [*ranges* bibliotek](https://en.cppreference.com/w/cpp/ranges), og spesielt interessant er introduksjonen av *pipe* (`|`) syntaksen:

```
#include <iostream>
#include <ranges>
#include <vector>

int main() {
  std::vector<int> numbers = {0, 1, 2, 3, 4, 5};

  for (auto e : numbers | std::views::reverse)
    std::cout << e << std::endl; // Outputs: 5 4 3 2 1 0

  for (auto e : numbers |
                    std::views::filter([](int e) { return e % 2 == 0; }) | // Keep only even numbers
                    std::views::transform([](int e) { return e * e; }))    // Square the remaining numbers
    std::cout << e << std::endl; // Outputs: 0 4 16
}
```

*Pipe* syntaksen er inspirert av Linux/Unix terminaler der en for eksempel kan skrive `ls | grep main` for å skrive ut liste over alle filer som inneholder ordet `main`.

For å kompilere eksempelet over må du aktivere C++20 ved å endre for eksempel `-std=c++1y` til `-std=c++20` i CMakeLists.txt. Du må også ha en nyere kompilator, som finnes i for eksempel Manjaro Linux.

## 

## Algoritmer i Rust

Det samme kan gjøres i Rust:

```
fn main() {
    let numbers = vec![0, 1, 2, 3, 4, 5];

    for e in numbers.iter().rev() {
        println!("{}", e) // Outputs: 5 4 3 2 1 0
    }

    for e in numbers.iter().filter(|e| (*e % 2) == 0).map(|e| e * e) {
        println!("{}", e) // Outputs: 0 4 16
    }
}
```

I Rust, som mange andre programmeringsspråk, heter funksjonen for å transformere data `map()` i stedet for `transform()`.

Merk at `|e| e * e` er en forenklet skrivemåte for `|e| { return e * e; }`