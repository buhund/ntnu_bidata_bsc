# INFT2503 - Leksjon 9: STL-algoritmer

Denne leksjonen gir eksempler på bruk av ulike typer STL-algoritmer.

Skrevet av Else Lervik, Tore Berg Hansen og Ole Christian Eidheim.

Eksemplene for denne leksjonen finner du her: https://gitlab.com/ntnu-iini4003/examples9

Støttelitteratur:

- Bjarne Stroustrup: A Tour of C++, Second Edition
  - kap. 12

## 

## Algoritmer for lineært søk

Fra grunnkurs i programmering er lineært søk kjent. Vi søker i en tabell ved å sammenlikne hvert enkelt element med den verdien vi leter etter. Søket avsluttes vanligvis når vi har funnet første forekomst av den verdien vi leter etter.

Programmet på filen search.cpp (se nedenfor) viser eksempler på bruk av STL-algoritmer som søker lineært i en sekvens. Funksjonene returnerer en iterator til resultatet.

```
#include <algorithm>
#include <iostream>
#include <string>
#include <vector>

using namespace std;

ostream &operator<<(ostream &out, const vector<int> &table) {
  for (auto &e : table)
    out << e << " ";
  return out;
}

int main() {
  vector<int> v1 = {3, 3, 12, 14, 17, 25, 30};
  cout << "v1: " << v1 << endl;

  vector<int> v2 = {2, 3, 12, 14, 24};
  cout << "v2: " << v2 << endl;

  // Søker etter enkeltverdi med find()
  auto pos = find(v1.begin(), v1.end(), 25);
  if (pos != v1.end()) {
    cout << "25 fins i v1 på indeks " << (pos - v1.begin()) << endl;
  } else
    cout << "25 fins ikke i v1" << endl;

  auto start = v1.begin() + 2;
  auto end = v1.end() - 2;
  cout << "Søker i en del av tabellen: ";
  for (auto it = start; it != end; ++it)
    cout << *it << " ";
  cout << endl;
  pos = find(start, end, 14);
  if (pos != end) {
    cout << "14 fins i v1 på indeks " << (pos - v1.begin()) << endl;
  } else
    cout << "14 fins ikke i v1" << endl;

  // Søker etter den første blant flere, find_first_of()
  // Søker i v1 {3, 3, 12, 14, 17, 25, 30} etter den første av
  // {12, 14, 24} (en del av v2). Svaret skal bli 2
  pos = find_first_of(v1.begin(), v1.end(), v2.begin() + 2, v2.end());
  cout << "Første på indeks " << (pos - v1.begin()) << endl;

  // Søker etter to like, ved siden av hverandre, adjacent_find()
  pos = adjacent_find(v1.begin(), v1.end());
  cout << "Finner to like på indeks " << (pos - v1.begin()) << endl;

  // Teller antall 3-tall i v1
  cout << "v1 inneholder " << count(v1.begin(), v1.end(), 3) << " 3-tall" << endl;

  // Finner største verdi i v1 (max_element returnerer en iterator)
  cout << "Største verdi i v1 er " << *max_element(v1.begin(), v1.end()) << endl; // dereferanse
}

/* Kjøring av programmet:
v1: 3 3 12 14 17 25 30
v2: 2 3 12 14 24
25 fins i v1 på indeks 5
Søker i en del av tabellen: 12 14 17
14 fins i v1 på indeks 3
Første på indeks 2
Finner to like på indeks 0
v1 inneholder 2 3-tall
Største verdi i v1 er 30
*/
```

La oss se nærmere på deler av programmet.

Vektoren `v1` har følgende verdier: `3 3 12 14 17 25 30`. Verdien `25` er på posisjon (indeks) `5`. Funksjonen `find()` returnerer en iterator til denne posisjonen:

```
auto pos = find(v1.begin(), v1.end(), 25);
```

[![img](https://eidheim.folk.ntnu.no/c++/9-algorithms/find.png)](https://eidheim.folk.ntnu.no/c++/9-algorithms/find.png)

Indeksen er gitt som avstanden mellom denne returverdien og begynnelsen på sekvensen. Det vil si `(pos - v1.begin())`. Studer kildekoden. Se figuren. Der har vi også vist returverdien dersom vi søker etter en verdi som ikke eksisterer (verdien `13`).

Programmet viser også hvordan vi kan søke i en del av tabellen.

`find_first_of()` lar oss søke etter én blant flere verdier. Også dette eksemplet søker i vektoren `v1`. Denne gangen skal søket stoppe når vi har funnet én av verdiene `{12, 14, 24}`, det vil si på indeks `2`.

Til slutt i programmet er det tatt med eksempel på bruk av `count()` og `max_element()`.

## 

## Algoritmer som endrer eller flytter på datainnholdet

Programmet under (algorithms.cpp) viser noen eksempler på bruk av algoritmer som flytter på og/eller endrer data. Vi skal gjennomgå deler av programmet.

```
#include <algorithm>
#include <iostream>
#include <string>
#include <vector>

using namespace std;

ostream &operator<<(ostream &out, const vector<int> &table) {
  for (auto &e : table)
    out << e << " ";
  return out;
}

int main() {
  vector<int> v1 = {3, 3, 12, 14, 17, 25, 30};
  cout << "v1: " << v1 << endl;
  vector<int> v2 = {2, 3, 12, 14, 24};
  cout << "v2: " << v2 << endl;

  swap(v1, v2); // bytter om v1 og v2
  cout << "Etter ombytting:" << endl;
  cout << "v1: " << v1 << endl;
  cout << "v2: " << v2 << endl;

  auto old_size = v1.size();
  v1.resize(v1.size() + v2.size());
  copy(v2.begin(), v2.end(), v1.begin() + old_size);
  cout << "Nå er v1 lik v1 + v2: " << v1 << endl;

  // Bytter om elementene [0, 5> og [5, 10>
  swap_ranges(v1.begin(), v1.begin() + 5, v1.begin() + 5);
  cout << "V1, byttet om elementene [0, 5> og [5, 10>: " << v1 << endl;

  // Legger inn 3 i de fem første elementene
  fill(v1.begin(), v1.begin() + 5, 3);
  cout << "V1 med tallet 3 i element [0, 5>: " << v1 << endl;

  // Lager en ny vektor der alle 3-tall er byttet ut med 300
  vector<int> copy;
  copy.resize(v1.size());
  replace_copy(v1.begin(), v1.end(), copy.begin(), 3, 300);
  cout << "Kopi: " << copy << endl;

  // Snur v1
  vector<int> v1_reversed(v1.size());
  reverse_copy(v1.begin(), v1.end(), v1_reversed.begin());
  cout << "V1, snudd: " << v1_reversed << endl;

  // Roterer v1 3 posisjoner
  cout << "V1, før rotasjonen: " << v1 << endl;
  rotate(v1.begin(), v1.begin() + 3, v1.end());
  cout << "V1, rotert 3 posisjoner: " << v1 << endl;

  // Lager en vektor med størrelse 3, finner deretter alle permutasjoner
  vector<int> table;
  table.emplace_back(1);
  table.emplace_back(2);
  table.emplace_back(3);
  // Antall permutasjoner er lik 3! = 1*2*3 = 6.
  // Lager sju permutasjoner, da skal perm. 7 være lik perm. 1
  for (size_t i = 0; i < 7; ++i) {
    next_permutation(table.begin(), table.end());
    cout << "Permutasjon " << (i + 1) << ": ";
    cout << table << endl;
  }
}

/* Kjøring av programmet:
v1: 3 3 12 14 17 25 30
v2: 2 3 12 14 24
Etter ombytting:
v1: 2 3 12 14 24
v2: 3 3 12 14 17 25 30
Nå er v1 lik v1 + v2: 2 3 12 14 24 3 3 12 14 17 25 30
V1, byttet om elementene [0, 5> og [5, 10>: 3 3 12 14 17 2 3 12 14 24 25 30
V1 med tallet 3 i element [0, 5>: 3 3 3 3 3 2 3 12 14 24 25 30
Kopi: 300 300 300 300 300 2 300 12 14 24 25 30
V1, snudd: 30 25 24 14 12 3 2 3 3 3 3 3
V1, før rotasjonen: 3 3 3 3 3 2 3 12 14 24 25 30
V1, rotert 3 posisjoner: 3 3 2 3 12 14 24 25 30 3 3 3
Permutasjon 1: 1 3 2
Permutasjon 2: 2 1 3
Permutasjon 3: 2 3 1
Permutasjon 4: 3 1 2
Permutasjon 5: 3 2 1
Permutasjon 6: 1 2 3
Permutasjon 7: 1 3 2
*/
```

Funksjonen `swap()` bytter om innholdet i to vektorer. Denne funksjonen eksisterer også som medlemsfunksjon. Det vil si at følgende to instruksjoner er ekvivalente:

```
v1.swap(v2);
swap(v1, v2);
```

Neste funksjon som blir demonstrert i programmet foran er `copy()`:

```
auto old_size = v1.size();
v1.resize(v1.size() + v2.size()); // må gjøre v1 stor nok
copy(v2.begin(), v2.end(), v1.begin() + old_size);
```

Funksjonen tar tre argumenter, som alle er iteratorer. De to første definerer intervallet som skal kopieres, den siste sier hvor kopien skal legges. Elementene dataene skal kopieres til, må eksistere.

Bruk av `resize()` fører ofte til at dataene må flyttes i primærlageret. Derfor vil eventuelle iteratorer, referanser og pekere til elementene i vektoren kunne være ødelagt etter en slik operasjon.

Vi kan altså ikke skrive f.eks. følgende:

```
vector<int>::iterator it = v1.end();
v1.resize(v1.size() + v2.size()); // her ødelegges it
copy(v2.begin(), v2.end(), it); // dette blir feil
```

------

**Merk**

Noen STL-algoritmer legger resultatet av operasjonen i en annen vektor enn den dataene lå i opprinnelig. Denne vektoren må på forhånd være stor nok (f.eks. ved at `resize()` er brukt). Dersom det ikke er tilfelle, kan uforutsette ting skje, på tilsvarende måte som når vi beveger oss utenfor det området som er satt av til en tabell. Husk også at `resize()` ødelegger eventuelle iteratorer.

------

I stedet for å sette av tilstrekkelig plass før funksjonskallet kan man bruke innsettingsiteratorer, men det behandles ikke her. Medlemsfunksjonen insert() bruker automatisk en slik iterator:

```
v1.insert(v1.end(), v2.begin(), v2.end());
```

Her utvides `v1` inne i funksjonen.

Nå inneholder `v1` `12` elementer: `2 3 12 14 24 3 3 12 14 17 25 30`.

`swap_ranges()` kan brukes til å bytte om de fem første elementene med de fem neste:

```
swap_ranges(v1.begin(), v1.begin() + 5, v1.begin() + 5);
```

Funksjonen tar tre argumenter. De to første sier hvilket intervall vi skal skifte ut, og det definerer dermed også antall elementer som skal byttes ut. Det tredje argumentet spesifiserer begynnelsen på det andre intervallet. Det andre intervallet er nødvendigvis like langt som det første. I stedet for `v1.begin() + 5` kunne vi skrevet `v1.end() - 7`.

Etter å ha lagt inn `3`-tall i de fem første elementene, bruker vi `replace_copy()` til å lage en vektor som er lik `v1`, men der alle `3`-tallene er byttet ut med `300`. Også her må vi passe på å sette av nok plass før vi kaller funksjonen:

```
vector<int> copy;
copy.resize(v1.size());
```

Programmet viser videre eksempler på reversering, rotering og permutering av en vektor. En permutasjon er en omstokking av elementene i en mengde.

## 

## Algoritmer på sorterte data

Det neste programmet (sort.cpp) viser eksempler på algoritmer som forutsetter at dataene er sortert. Eksempelvis kan søking gjøres mye mer effektivt i en sortert mengde enn i en usortert.

```
#include <algorithm>
#include <iostream>
#include <string>
#include <vector>

using namespace std;

ostream &operator<<(ostream &out, const vector<int> &table) {
  for (auto &e : table)
    out << e << " ";
  return out;
}

int main() {
  vector<int> v1 = {3, 3, 12, 14, 17, 25, 30};
  cout << "v1: " << v1 << endl;

  vector<int> v2 = {2, 3, 12, 14, 24};
  cout << "v2: " << v2 << endl;

  // Binærsøk. Funksjonen binary_search() sier om et element
  // er i en vektor, men ikke hvor. Bruker lower_bound()
  // (ev. upper_bound()) til å fortelle oss det.
  if (binary_search(v1.begin(), v1.end(), 17)) {
    cout << "17 fins i v1\n";
  } else
    cout << "17 fins ikke i v1\n";

  // Verdien 17 er i v1, men på hvilken indeks?
  auto pos = lower_bound(v1.begin(), v1.end(), 17);
  cout << "17 er på indeks " << (pos - v1.begin()) << endl;

  // 25 er ikke i v2. Lager en kopi av v2, skal sette inn 25 der.
  auto v3 = v2;
  pos = lower_bound(v3.begin(), v3.end(), 25);
  cout << "25 skal inn på posisjon " << (pos - v3.begin()) << endl;
  v3.insert(pos, 25);
  cout << "V3 er lik v2 med 25 satt inn: " << v3 << endl;

  // Includes
  if (includes(v1.begin(), v1.end(), v2.begin() + 1, v2.begin() + 3))
    cout << "Er med!\n";
  else
    cout << "Er ikke med!\n";

  // Fletting
  vector<int> result;
  result.resize(v1.size() + v2.size()); // eksakt riktig størrelse
  merge(v1.begin(), v1.end(), v2.begin(), v2.end(), result.begin());
  cout << "V1 og V2 flettet: " << result << endl;

  // Fjerner dubletter i result
  auto end = unique(result.begin(), result.end());
  result.erase(end, result.end()); // reduserer størrelsen
  cout << "V1 og V2 flettet, uten dubletter: " << result << endl;

  // Mengdeoperasjoner
  result.resize(v1.size() + v2.size()); // minst stort nok
  end = set_union(v1.begin(), v1.end(), v2.begin(), v2.end(), result.begin());
  result.erase(end, result.end()); // reduserer størrelsen
  cout << "V1 union V2: " << result << endl;

  result.resize(v1.size() + v2.size()); // minst stort nok
  end = set_intersection(v1.begin(), v1.end(), v2.begin(), v2.end(), result.begin());
  result.erase(end, result.end());
  cout << "V1 snitt V2: " << result << endl;
}

/* Kjøring av programmet:
v1: 3 3 12 14 17 25 30
v2: 2 3 12 14 24
17 fins i v1
17 er på indeks 4
25 skal inn på posisjon 5
V3 er lik v2 med 25 satt inn: 2 3 12 14 24 25
Er med!
V1 og V2 flettet: 2 3 3 3 12 12 14 14 17 24 25 30
V1 og V2 flettet, uten dubletter: 2 3 12 14 17 24 25 30
V1 union V2: 2 3 3 12 14 17 24 25 30
V1 snitt V2: 3 12 14
*/
```

Binærsøk fungerer slik: I en sortert tabell vet vi at små verdier ligger i begynnelsen av tabellen og store i slutten. Hvis vi sammenlikner verdien på midterste element med det vi leter etter, kan vi finne ut om det vi leter etter, hører til i første eller siste halvdel av tabellen. Den delen av tabellen der elementet i hvert fall ikke fins, kan vi da bare glemme. Deretter undersøker vi verdien på midtelementet i den halvdelen som fortsatt er av interesse, og kutter igjen vekk den delen der elementet ikke fins. Slik fortsetter vi til vi enten støter på den verdien vi er på jakt etter, eller ikke har noen elementer igjen. Da kan vi fastslå at verdien ikke fins.

Funksjonen `binary_search()` finner ut om en verdi fins i en sekvens. For å finne ut hvor verdien er, eventuelt på hvilken plass den skal settes inn for at sekvensen fortsatt skal være sortert, må vi bruke `lower_bound()` eller `upper_bound()`.

Eksempel: Gitt sekvensen `2, 3, 3, 3, 12, 14, 17, 25, 30`,

`lower_bound()` gir oss en iterator til det første elementet som er større eller lik den verdien vi søker. Dersom vi søker etter verdien `3`, som fins i tabellen, får vi en iterator til elementet med indeks `1`.

Dersom vi i stedet søker etter `3` med `upper_bound()`, får vi en iterator til elementet med indeks `4`, det vil si det første elementet *etter* sekvensen med `3`-tall. `upper_bound()` gir oss dermed den høyeste posisjonen hvor et nytt `3`-tall kunne plasseres slik at sekvensen fortsatt var sortert. Dersom vi vil ha posisjonen til siste `3`-tall, må vi trekke `1` fra den verdien som `upper_bound()` returnerer.

Programmet lager en kopi av `v2` (`2, 3, 12, 14, 24`) og bruker `lower_bound()` til å finne den posisjonen tallet `25` skal settes inn på:

```
auto v3 = v2;
pos = lower_bound(v3.begin(), v3.end(), 25);
cout << "25 skal inn på posisjon " << (pos - v3.begin()) << endl; // finner indeksen
v3.insert(pos, 25); // bruker iteratoren, ikke indeksen
```

Kodebiten skriver ut *indeksen*, men den bruker *iteratoren* i `insert()`-funksjonen.

En mer omfattende søkealgoritme er implementert i funksjonen `includes()`. Denne bruker vi dersom vi vil finne ut om alle elementene i en sortert mengde er med i en annen sortert mengde. I eksemplet finner vi ut om en nærmere spesifisert del av `v2` er med i `v1`:

```
if (includes(v1.begin(), v1.end(), v2.begin() + 1, v2.begin() + 3))
  cout << "Er med!\n";
else
  cout << "Er ikke med!\n";
```

Fletting er en prosess som slår sammen to sorterte sekvenser til én. Funksjonen `merge()` gjør denne jobben for oss. Vi må bare passe på at det er plass til resultatet i den konteineren der vi vil legge det:

```
vector<int> resultat;
resultat.resize(v1.size() + v2.size()); // eksakt riktig størrelse
merge(v1.begin(), v1.end(), v2.begin(), v2.end(), resultat.begin());
```

Til slutt viser programmet eksempler på mengdeoperasjonene union og snitt. La oss se på union. Vi begynner med å lage vektoren `result` så stor at det er plass til alle elementene fra både `v1` og `v2`. Både union og snitt vil ofte gi et resultat der antall elementer er færre enn det vi begynte med. Funksjonene returnerer en iterator til den "nye enden" av vektoren, men elementene bak fjernes ikke. For å redusere størrelsen på vektoren må vi bruke `erase()`. Merk at resultatmengden ikke nødvendigvis er en mengde i matematisk forstand. Den kan inneholde dubletter. Dersom vi vil ha vekk dem, bruker vi funksjonen `unique()`. 
