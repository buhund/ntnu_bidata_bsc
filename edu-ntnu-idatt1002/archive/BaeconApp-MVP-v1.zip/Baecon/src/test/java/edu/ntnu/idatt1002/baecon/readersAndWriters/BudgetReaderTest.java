package edu.ntnu.idatt1002.baecon.readersAndWriters;

import static org.junit.jupiter.api.Assertions.*;

import edu.ntnu.idatt1002.baecon.data.BudgetEntry;
import java.io.File;
import java.util.List;
import java.util.UUID;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class BudgetReaderTest {

  @Test
  @DisplayName("Test that the BudgetReader can read a budget entry from a file with budget entries")
  void testing_reading_all_budget_entries_in_a_month_from_a_file() {
    BudgetReader budgetReader = new BudgetReader();
    File file = new File ("src/main/resources/edu/ntnu/idatt1002/"
        + "baecon/dataFiles/budgetEntries.csv");
    try {
      List<BudgetEntry> budgetEntries = budgetReader.readAllBudgetEntriesInAMonthFromFile(file);
      assertTrue(budgetEntries.size() > 0);
      for (BudgetEntry budgetEntry : budgetEntries) {
        assertEquals(UUID.class, budgetEntry.getId());
      }
    } catch (Exception e) {
      e.getMessage();
      fail();
    }
  }

  @Test
  @DisplayName("Test that the BudgetReader throws an exception when trying to read "
      + "a file that does not exist")
  void testing_reading_all_budget_entries_from_a_file_that_is_not_a_csv_file() {
    BudgetReader budgetReader = new BudgetReader();
    File file = new File("src/test/resources/edu.ntnu.idatt1002.baecon."
        + "dataFiles/budgetEntries.txt");
    try {
      budgetReader.readAllBudgetEntriesInAMonthFromFile(file);
    } catch (Exception e) {
      assertEquals("Unsupported file format. Only .csv files are supported.",
          e.getMessage());
    }
  }

  @Test
  @DisplayName("Test that the BudgetReader throws an exception when trying to read "
      + "a file that does not exist")
  void testing_reading_all_budget_entries_from_a_file_that_does_not_exist() {
    BudgetReader budgetReader = new BudgetReader();
    File file = new File("nonexistentFile.csv");
    try {
      budgetReader.readAllBudgetEntriesInAMonthFromFile(file);
    } catch (Exception e) {
      assertEquals("Unable to read budget entries from file " + file.getName() + ".",
          e.getMessage());
    }
  }
}