package edu.ntnu.idatt1002.baecon.readersAndWriters;

import edu.ntnu.idatt1002.baecon.data.Receipt;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.IOException;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

class ReceiptWriterTest {

  @Test
  void write_receipt_to_file () {
    String testDescription = "Test Description";
    Date testDate = new Date();
    File testPdfFilePath = new File("");
    File testFilePath = new File("src/test/resources/edu.ntnu.idatt1002.baecon.dataFiles/receipts.csv");

    Receipt receipt = new Receipt(testDescription, testDate, testPdfFilePath);
    ReceiptWriter receiptWriter = new ReceiptWriter();
    long numberOfLinesBefore = testFilePath.length();

    try {
      receiptWriter.writeReceiptToFile(receipt, testFilePath);
      long numberOfLinesAfter = testFilePath.length();
      assertTrue(numberOfLinesAfter > numberOfLinesBefore);
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }

  @Test
  void write_to_non_valid_file() {
    String testDescription = "Test Description";
    Date testDate = new Date();
    File testPdfFilePath = new File("");
    File testFilePath = new File("src/test/resources/edu.ntnu.idatt1002.baecon.dataFiles/receipts.txt");
    String expectedMessage = "Unsupported file format. Only .csv files are supported.";

    Receipt receipt = new Receipt(testDescription, testDate, testPdfFilePath);
    ReceiptWriter receiptWriter = new ReceiptWriter();

    try {
      receiptWriter.writeReceiptToFile(receipt, testFilePath);
    } catch (IOException e) {
      assertEquals(expectedMessage, e.getMessage());
    }
  }

  @Test
  void test_write_to_file_that_does_not_exist () {
    String testDescription = "Test Description";
    Date testDate = new Date();
    File testPdfFilePath = new File("");
    File testFilePath = new File("nonexistenFile.csv");

    Receipt receipt = new Receipt(testDescription, testDate, testPdfFilePath);
    ReceiptWriter receiptWriter = new ReceiptWriter();
    long numberOfLinesBefore = testFilePath.length();

    try {
      receiptWriter.writeReceiptToFile(receipt, testFilePath);
      long numberOfLinesAfter = testFilePath.length();
      assertTrue(numberOfLinesAfter > numberOfLinesBefore);
    } catch (IOException e) {
      assertEquals(e.getMessage(), "File does not exist. Unable to write to file that does not " +
              "exist.");
    }
  }
}
