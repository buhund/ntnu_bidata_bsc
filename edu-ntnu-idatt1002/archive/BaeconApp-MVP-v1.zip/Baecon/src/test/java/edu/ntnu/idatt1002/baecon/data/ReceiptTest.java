package edu.ntnu.idatt1002.baecon.data;

import org.junit.jupiter.api.Test;

import java.io.File;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

class ReceiptTest {

  @Test
  void creates_receipt_object_with_valid_arguments() {
    String testDescription = "Test description";
    Date testDate = new Date();
    File testfile = new File("Pathname");

    try {
      Receipt receipt = new Receipt(testDescription, testDate, testfile);
    }catch (Exception e) {
      fail();
    }
  }

  @Test
  void throws_IEA_with_null_description() {
    String wrongDescription = "";
    Date testDate = new Date();
    File testfile = new File("Pathname");

    String expectedMessage = "Description missing";

    try{
      Receipt receipt = new Receipt(wrongDescription, testDate, testfile);
    } catch (IllegalArgumentException e){
      assertEquals(expectedMessage, e.getMessage());
    }
  }

  @Test
  void throws_IEA_with_null_filepath() {
    String description = "Test description";
    Date testDate = new Date();
    File wrongTestpathname = new File("");

    String expectedMessage = "No file path defined";

    try{
      Receipt receipt = new Receipt(description, testDate, wrongTestpathname);
    } catch (IllegalArgumentException e){
      assertEquals(expectedMessage, e.getMessage());
    }
  }

  @Test
  void throws_IEA_with_null_date() {
    String description = "Test description";
    Date wrongTestDate = null;
    File testpathname = new File("");

    String expectedMessage = "Date must be set!";

    try{
      Receipt receipt = new Receipt(description, wrongTestDate, testpathname);
    } catch (IllegalArgumentException e){
      assertEquals(expectedMessage, e.getMessage());
    }
  }

}