package edu.ntnu.idatt1002.baecon.readersAndWriters;

import edu.ntnu.idatt1002.baecon.data.Receipt;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

class ReceiptReaderTest {
  @Test
  void test_read_all_receipts_from_file_with_receipts () {

    ReceiptReader receiptReader = new ReceiptReader();
    File testFilePath = new File("src/test/resources/edu.ntnu.idatt1002.baecon.dataFiles/receipts.csv");

    try {
      List<Receipt> receipts = receiptReader.readAllReceiptsFromFile(testFilePath);

      assertTrue(receipts.size() > 0);

      for (Receipt receipt: receipts) {
        assertEquals(receipt.getId().getClass(), UUID.class);
      }
    } catch (IOException e) {
      throw new RuntimeException(e);
    } catch (ParseException e) {
      throw new RuntimeException(e);
    }
  }

  @Test
  void test_throw_exception_when_giving_non_valid_file_path() {
    ReceiptReader receiptReader = new ReceiptReader();
    File testFilePath = new File("src/test/resources/edu.ntnu.idatt1002.baecon.dataFiles/receipts.txt");
    String expectedMessege = "Unsupported file format. Only .csv files are supported.";

    try {
      receiptReader.readAllReceiptsFromFile(testFilePath);
    } catch (IOException e) {
      assertEquals(expectedMessege, e.getMessage());
    } catch (ParseException e) {
      throw new RuntimeException(e);
    }
  }
}