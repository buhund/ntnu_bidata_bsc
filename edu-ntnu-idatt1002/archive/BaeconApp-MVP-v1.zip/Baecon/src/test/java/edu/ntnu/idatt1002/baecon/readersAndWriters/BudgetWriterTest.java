package edu.ntnu.idatt1002.baecon.readersAndWriters;

import static org.junit.jupiter.api.Assertions.*;

import edu.ntnu.idatt1002.baecon.data.BudgetEntry;
import edu.ntnu.idatt1002.baecon.data.Category;
import java.io.File;
import java.util.Date;
import java.util.UUID;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class BudgetWriterTest {

  @Test
  @DisplayName("Test that the BudgetEntryWriter can write a budget entry to a file")
  void testing_writing_a_budget_entry_to_a_file() {
    UUID testId = UUID.randomUUID();
    boolean testExpense = true;
    double testAmount = 199.99;
    String testDescription = "Test description";
    Category testCategory = new Category(UUID.randomUUID(), testDescription);
    BudgetEntry budgetEntry = new BudgetEntry(testId, testExpense, testAmount,
        testCategory.getId());
    BudgetWriter budgetWriter = new BudgetWriter();
    File file = new File ("src/test/resources/edu.ntnu.idatt1002.baecon."
        + "dataFiles/budgetEntries.csv");
    long numberOfLinesBefore = file.length();
    try {
      budgetWriter.writeBudgetEntryToFile(budgetEntry,file);
      long numberOfLinesAfter = file.length();
      assertTrue(numberOfLinesAfter > numberOfLinesBefore);
    } catch (Exception e) {
      e.getMessage();
    }
  }

  @Test
  @DisplayName("Test that the BudgetWriter throws an exception when trying to write to a"
      + " file that is not a csv file")
  void test_write_an_budget_entry_to_a_file_that_is_not_a_Csv_File() {
    UUID testId = UUID.randomUUID();
    boolean testExpense = true;
    double testAmount = 199.99;
    String testDescription = "Test description";
    Category testCategory = new Category(UUID.randomUUID(), testDescription);
    BudgetEntry budgetEntry = new BudgetEntry(testId, testExpense, testAmount,
        testCategory.getId());
    BudgetWriter budgetWriter = new BudgetWriter();
    File file = new File ("src/test/resources/edu.ntnu.idatt1002.baecon."
        + "dataFiles/budgetEntries.csv.txt");
    try {
      budgetWriter.writeBudgetEntryToFile(budgetEntry, file);
    } catch (Exception e) {
      assertEquals(e.getMessage(), "Unsupported file format. Only .csv files are supported.");
    }
  }

  @Test
  @DisplayName("Test that the budgetWriter can not write an accounting entry to a "
      + "file that does not exist")
  void testing_writing_an_budget_entry_to_a_file_that_does_not_exist() {
    UUID testId = UUID.randomUUID();
    boolean testExpense = true;
    double testAmount = 199.99;
    String testDescription = "Test description";
    Category testCategory = new Category(UUID.randomUUID(), testDescription);
    BudgetEntry budgetEntry = new BudgetEntry(testId, testExpense, testAmount,
        testCategory.getId());
    BudgetWriter budgetWriter = new BudgetWriter();
    File file = new File("nonexistentFile.csv");
    try {
      budgetWriter.writeBudgetEntryToFile(budgetEntry,file);
    } catch (Exception e) {
      assertEquals(e.getMessage(), "File does not exist. Unable to write to file that "
          + "does not exist.");
    }
  }
}