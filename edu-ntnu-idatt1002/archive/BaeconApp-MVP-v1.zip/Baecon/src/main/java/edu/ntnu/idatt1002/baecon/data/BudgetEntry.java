package edu.ntnu.idatt1002.baecon.data;

import java.util.Date;
import java.util.UUID;

/**
 * The BudgetEntry class, inheriting from the Entry class.
 * Handling the budget entry's
 * by an id, an expense, a date, an amount and a category of the entry.
 */
public class BudgetEntry extends Entry {

  /**
   * Constructor of the Entry class.
   *
   * @param expense  true for expense and false for income (boolean)
   * @param amount   the amount of an entry in norwegian kroner (double)
   * @param categoryId the category of an entry (Category)
   */
  public BudgetEntry(boolean expense, double amount, UUID categoryId) {
    super(expense, amount, categoryId);
  }

  /**
   * Alternative constructor of the Entry class, accepting id as a parameter.
   *
   * @param id       the id of the entry (UUID)
   * @param expense  true for expense and false for income (boolean)
   * @param amount   the amount of an entry in norwegian kroner (double)
   * @param categoryId the category of an entry (Category)
   */
  public BudgetEntry(UUID id, boolean expense, double amount,
      UUID categoryId) {
    super(id, expense, amount, categoryId);
  }
}
