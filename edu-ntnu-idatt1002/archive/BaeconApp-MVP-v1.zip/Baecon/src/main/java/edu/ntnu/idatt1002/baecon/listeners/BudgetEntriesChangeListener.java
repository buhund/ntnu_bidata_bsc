package edu.ntnu.idatt1002.baecon.listeners;

import edu.ntnu.idatt1002.baecon.data.AccountingEntry;
import edu.ntnu.idatt1002.baecon.data.BudgetEntry;

import java.util.List;

public interface BudgetEntriesChangeListener {
  void update(List<BudgetEntry> budgetEntries);
}
