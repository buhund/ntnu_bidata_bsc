package edu.ntnu.idatt1002.baecon.controller;

import edu.ntnu.idatt1002.baecon.data.BudgetEntry;
import edu.ntnu.idatt1002.baecon.listeners.AccountingEntriesChangeListener;
import edu.ntnu.idatt1002.baecon.listeners.BudgetEntriesChangeListener;
import edu.ntnu.idatt1002.baecon.readersAndWriters.AccountingReader;
import edu.ntnu.idatt1002.baecon.readersAndWriters.AccountingWriter;
import edu.ntnu.idatt1002.baecon.readersAndWriters.BudgetReader;
import edu.ntnu.idatt1002.baecon.readersAndWriters.BudgetWriter;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

public class BudgetEntriesController {

  public static BudgetEntriesController instance = null;
  private List<BudgetEntriesChangeListener> listeners;
  private List<BudgetEntry> budgetEntries;
  private BudgetReader budgetReader;
  private BudgetWriter budgetWriter;

  /**
   * Constructor for instantiating a new BudgetEntriesController.
   */
  private BudgetEntriesController() {
    listeners = new ArrayList<>();
    budgetReader = new BudgetReader();
    budgetWriter = new BudgetWriter();
    loadEntries();
  }

  /**
   * Method to get the instance of a BudgetEntriesController.
   *
   * @return instance of BudgetEntriesController
   */
  public static BudgetEntriesController getInstance() {
    if ( instance == null) {
      instance = new BudgetEntriesController();
    }
    return instance;
  }

  /**
   * Method to add a listener to the list of listeners.
   *
   * @return {@code List} of BudgetEntriesController
   */
  public List<BudgetEntry> getBudgetEntries() {
    return budgetEntries;
  }

  /**
   * This method retrieves all entries from a file but using {@code BudgetReader}.
   *
   * @throws IOException io exception
   * @throws ParseException parse exception
   */
  public void loadEntries() {
    File file = new File(String.format("src/main/resources/edu/ntnu/idatt1002/baecon/dataFiles/budgetEntries.csv"));

    try {
      budgetEntries = budgetReader.readAllBudgetEntriesInAMonthFromFile(file);
    } catch (IOException e) {
      System.out.println(e.getMessage());
      budgetEntries = new ArrayList<>();
    }
    listeners.forEach(listener -> listener.update(budgetEntries));
  }

  /**
   * This method adds a new budget entry to the file and updates the list of budget entries.
   *
   * @param newBudgetEntry as BudgetEntry
   * @throws IOException io exception
   */
  public void addNewBudgetEntry( BudgetEntry newBudgetEntry) throws IOException {
    File file = new File(String.format("src/main/resources/edu/ntnu/idatt1002/baecon/dataFiles/budgetEntries.csv"));
    budgetWriter.writeBudgetEntryToFile(newBudgetEntry,file);

    loadEntries();
  }

  /**
   * This method edits a budget entry.
   *
   * @param editedBudgetEntry as BudgetEntry
   */
  public void editBudgetEntry (BudgetEntry editedBudgetEntry) {
    BudgetEntry budgetEntryToEdit = budgetEntries.stream().
            filter(budgetEntry -> budgetEntry.getId().equals(editedBudgetEntry.getId())).findFirst().orElse(null);
  if (budgetEntryToEdit == null) {
    throw new IllegalArgumentException("Can not find this budget entry");
  }
  budgetEntryToEdit = editedBudgetEntry;
  }

  /**
   * This method removes a budget entry.
   *
   * @param budgetEntry as BudgetEntry
   */
  public void removeBudgetEntry(BudgetEntry budgetEntry) {
    budgetEntries.remove(budgetEntry);
  }

  /**
   * This method adds a listener to the list of listeners.
   *
   * @param listener as BudgetEntriesChangeListener
   */
  public void addSubscriber(BudgetEntriesChangeListener listener){
    listeners.add(listener);
  }
}
