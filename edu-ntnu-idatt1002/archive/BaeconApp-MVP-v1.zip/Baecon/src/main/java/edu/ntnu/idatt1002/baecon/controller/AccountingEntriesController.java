package edu.ntnu.idatt1002.baecon.controller;

import edu.ntnu.idatt1002.baecon.data.AccountingEntry;
import edu.ntnu.idatt1002.baecon.listeners.AccountingEntriesChangeListener;
import edu.ntnu.idatt1002.baecon.readersAndWriters.AccountingReader;
import edu.ntnu.idatt1002.baecon.readersAndWriters.AccountingWriter;
import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Class responsible for handling accountingEntries.
 */
public class AccountingEntriesController {
  public static AccountingEntriesController instance = null;
  private List<AccountingEntriesChangeListener> listeners;
  private List<AccountingEntry> accountingEntries;
  private AccountingReader accountingReader;
  private AccountingWriter accountingWriter;
  private String currentMonth;
  private String currentYear;

  /**
   * Constructor to initiate a new AccountingEntriesController.
   */
  private AccountingEntriesController() {
    listeners = new ArrayList<>();
    accountingReader = new AccountingReader();
    accountingWriter = new AccountingWriter();
    Date todaysDate = new Date();
    currentYear = String.valueOf(todaysDate.getYear() + 1900);
    currentMonth = String.format("%02d", todaysDate.getMonth() + 1);

    loadEntries(currentMonth, currentYear);
  }

  /**
   * Method to get the instance of AccountingEntriesController.
   *
   * @return the AccountingEntriesController
   */
  public static AccountingEntriesController getInstance() {
    if (instance == null) {
      instance = new AccountingEntriesController();
    }
    return instance;
  }

  /**
   * Method to get the accountingEntries.
   *
   * @return a list of {@code AccountingEntry}
   */
  public List<AccountingEntry> getAccountingEntries() {
    return accountingEntries;
  }

  /**
   * Method to load entries from file using the accountingEntryReader.
   *
   * @param month the month of entries
   * @param year the year of entries
   * @throws IOException io exception
   * @throws ParseException parse exception
   */
  public void loadEntries(String month, String year) {
    File file = new File(String.format("src/main/resources/edu/ntnu/idatt1002/baecon/dataFiles/%s.%s.csv", month, year));

    try {
      accountingEntries = accountingReader.readAllAccountingEntriesInAMonthFromFile(file);
    } catch (IOException e) {
      System.out.println(e.getMessage());
      accountingEntries = new ArrayList<>();
    } catch (ParseException e) {
      System.out.println(e.getMessage());
    }
    listeners.forEach(listener -> listener.updateAccountingEntries(accountingEntries));
  }

  /**
   * Method to add a newAccountingEntry to file.
   *
   * @param newAccountingEntry the new accounting entry
   * @throws IOException io exception
   */
  public void addNewAccountingEntry(AccountingEntry newAccountingEntry) throws IOException {
    String month = String.format("%02d", newAccountingEntry.getDate().getMonth() + 1);
    String year = String.valueOf(newAccountingEntry.getDate().getYear() + 1900);

    File file = new File(String.format("src/main/resources/edu/ntnu/idatt1002/baecon/dataFiles/%s.%s.csv", month, year));
    accountingWriter.writeAccountingEntryToFile(newAccountingEntry, file);

    loadEntries(month, year);
  }

  /**
   * Method to edit an accounting entry.
   *
   * @param editedAccountingEntry the accounting entry to edit
   */
  public void editAccountingEntry(AccountingEntry editedAccountingEntry) {
    AccountingEntry accountingEntryToEdit = accountingEntries.stream()
      .filter(accountingEntry -> accountingEntry.getId().equals(editedAccountingEntry.getId()))
      .findFirst()
      .orElse(null);

    if (accountingEntryToEdit == null) {
      throw new IllegalArgumentException("Could not find accountingEntry");
    }

    accountingEntryToEdit = editedAccountingEntry;
  }

  /**
   * Method to remove an {@code AccountingEntry}.
   *
   * @param accountingEntry the AccountingEntry to remove
   */
  public void removeAccountingEntry(AccountingEntry accountingEntry) {
    accountingEntries.remove(accountingEntry);
  }

  /**
   * Method to add a new subscriber to the list of listeners.
   *
   * @param listener the new subscriber
   */
  public void addSubscriber(AccountingEntriesChangeListener listener) {
    listeners.add(listener);
  }
}
