package edu.ntnu.idatt1002.baecon.controller;

import edu.ntnu.idatt1002.baecon.data.Category;
import edu.ntnu.idatt1002.baecon.listeners.CategoriesChangeListener;
import edu.ntnu.idatt1002.baecon.scenes.View;
import edu.ntnu.idatt1002.baecon.scenes.ViewSwitcher;
import java.io.IOException;
import java.text.ParseException;
import java.util.List;
import java.util.Objects;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.stage.Stage;

public class SettingsPageController implements CategoriesChangeListener {

  TabPane settings;
  Tab generalSettings;
  Tab accessibilitySettings;
  Tab categoriesSettings;
  @FXML ListView<String> categoriesListView;
  ComboBox currencyPicker;
  CheckBox negativeNumbersRed;
  CheckBox colorBlindMode;
  CheckBox checkBox1;
  CheckBox checkBox2;
  CheckBox checkBox3;

  Button newCategoryButton;
  Button editCategoryButton;
  Button deleteCategoryButton;

  // TODO Possibly move each settings category (tab) to its own xyzController.java?
  private CategoriesController categoriesController;


  @FXML
  public void initialize() throws IOException, ParseException {
    // TODO Stuff
    categoriesController = CategoriesController.getInstance();
    categoriesController.addSubscriber(this);

    categoriesController.getCategories().forEach(category -> {
      categoriesListView.getItems().add(category.getName());
    });
  }

  @FXML
  void onSettingsNewCategoryDialog() throws IOException {
    Stage newCategoryStage = new Stage();
    newCategoryStage.setTitle("Baecon - New Category");
    FXMLLoader settingsCategoryDialogFXML = new FXMLLoader(Objects.requireNonNull(ViewSwitcher.class.
        getResource(View.SETTINGS_CATEGORY_ENTRY.getFileName())));
    settingsCategoryDialogFXML.load();

    SettingsCategoryDialogController setCatDiaController = settingsCategoryDialogFXML.getController();
    setCatDiaController.initData(true, newCategoryStage);


    newCategoryStage.setScene(new Scene(settingsCategoryDialogFXML.getRoot()));
    newCategoryStage.show();
  }

  @FXML
  void onSettingsEditCategoryDialog() throws IOException {
    Stage editCategoryStage = new Stage();
    editCategoryStage.setTitle("Baecon - Edit Category");
    FXMLLoader settingsCategoryDialogFXML = new FXMLLoader(Objects.requireNonNull(ViewSwitcher.class.
        getResource(View.SETTINGS_CATEGORY_ENTRY.getFileName())));
    settingsCategoryDialogFXML.load();

    SettingsCategoryDialogController setCatDiaController = settingsCategoryDialogFXML.getController();
    setCatDiaController.initData(false, editCategoryStage);

    editCategoryStage.setScene(new Scene(settingsCategoryDialogFXML.getRoot()));
    editCategoryStage.show();

  }

  @FXML
  void onSettingsDeleteCategoryConfirmation() throws IOException {
    // TODO Makeke metodo
  }

  @FXML
  void onApplyCategoryButton () {
    // TODO Make stuff
  }

  @FXML
  void onCancelCategoryButton () {
    // TODO Make stuff
  }

  @Override
  public void updateCategories(List<Category> categories) {
    categoriesListView.getItems().clear();
    categories.forEach(category -> {
      categoriesListView.getItems().add(category.getName());
    });
  }
}
