package edu.ntnu.idatt1002.baecon.controller;

import edu.ntnu.idatt1002.baecon.data.BudgetEntry;
import edu.ntnu.idatt1002.baecon.data.Category;
import edu.ntnu.idatt1002.baecon.readersAndWriters.BudgetWriter;
import edu.ntnu.idatt1002.baecon.readersAndWriters.CategoryReader;
import java.io.File;
import java.io.IOException;
import java.util.List;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class AddBudgetEntryController {
  @FXML private Text titleEntryText;
  @FXML private Label expectedAmountLabel;
  @FXML private TextField expectedAmountTextField;
  @FXML private ComboBox categoryNameComboBox;
  @FXML private Button addEntryButton;

  private List<Category> categories;
  private CategoryReader categoryReader = new CategoryReader();
  private BudgetWriter budgetWriter = new BudgetWriter();
  private boolean isExpense;
  private Stage currentStage;

  @FXML
  public void initialize() throws IOException {
    //categories = categoryReader.readAllCategoriesFromFile(new File("src/main/resources/edu/ntnu/idatt1002/baecon/dataFiles/categories.csv"));

    CategoriesController.getInstance().getCategories().forEach(category -> {
      categoryNameComboBox.getItems().add(category.getName());
    });
  }

  /**
   * Method to init budget view with isExpense as a variable.
   *
   * @param isExpense is expense
   */
  public void initData(boolean isExpense, Stage currentStage) {
    this.isExpense = isExpense;
    this.currentStage = currentStage;
    // Set the title field depending on isExpense: Return Expense if true, else Income
    titleEntryText.setText("New " + (isExpense ? "Expense" : "Income"));
    expectedAmountLabel.setText(isExpense ? "Expected expense" : "Expected income");
    addEntryButton.setText("Add " + (isExpense ? "expense" : "income"));
  }

  @FXML
  public void addNewBudgetEntry() {
    try {
      Double amount = Double.parseDouble(expectedAmountTextField.getText());
      Category chosenCategory = CategoriesController.getInstance().getCategoryByDescription(categoryNameComboBox.getValue().toString());

      // Create new category from input
      if (chosenCategory == null) {
        
      }

      BudgetEntry newBudgetEntry = new BudgetEntry(isExpense, amount, chosenCategory.getId());

      BudgetEntriesController.getInstance().addNewBudgetEntry(newBudgetEntry);

      // Close stage
      currentStage.close();
    } catch (NumberFormatException numberFormatException) {
      Alert alert = new Alert(Alert.AlertType.ERROR, numberFormatException.getMessage());
      alert.show();
    } catch (IllegalArgumentException illegalArgumentException) {
      Alert alert = new Alert(Alert.AlertType.ERROR, illegalArgumentException.getMessage());
      alert.show();
      System.out.println(illegalArgumentException.getMessage());
    } catch (IOException ioException) {
      Alert alert = new Alert(Alert.AlertType.ERROR, ioException.getMessage());
      alert.show();
    }
  }
}
