package edu.ntnu.idatt1002.baecon.controller;

import java.io.IOException;
import java.text.ParseException;
import javafx.fxml.FXML;

public class ReceiptsPageController {



  @FXML
  public void initialize() throws IOException, ParseException {
    // TODO Stuff
  }

}
