package edu.ntnu.idatt1002.baecon.controller;

import edu.ntnu.idatt1002.baecon.data.BudgetEntry;
import edu.ntnu.idatt1002.baecon.data.Category;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.text.Text;

import java.util.List;

public class BudgetEntryController {

  @FXML private Text categoryText;
  @FXML private Text amountText;
  @FXML private Button editButton;
  @FXML private Button deleteButton;

  @FXML
  public void initialize() {}

  /**
   * This method initializes the data for the budget entry.
   *
   * @param budgetEntry as {@code BudgetEntry}
   */
  public void initBudgetEntryData (BudgetEntry budgetEntry) {
    Category currentCategory = CategoriesController.getInstance().getCategoryById(budgetEntry.getCategoryId());


    if (currentCategory == null) {
      throw new IllegalArgumentException("Category does not exist");
    }
    categoryText.setText(currentCategory.getName());
    amountText.setText(String.format("%s%.2f kr", budgetEntry.isExpense() ? "-" : "", budgetEntry.getAmount()));

    editButton.setOnAction(actionEvent -> {
      System.out.println("edit entry: " + budgetEntry.getId());
    });

    deleteButton.setOnAction(actionEvent -> {
      System.out.println("delete entry: " + budgetEntry.getId());
    });
  }
}