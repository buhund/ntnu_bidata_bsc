package edu.ntnu.idatt1002.baecon.listeners;

import edu.ntnu.idatt1002.baecon.data.Category;
import java.util.List;

public interface CategoriesChangeListener {
  void updateCategories(List<Category> categories);
}
