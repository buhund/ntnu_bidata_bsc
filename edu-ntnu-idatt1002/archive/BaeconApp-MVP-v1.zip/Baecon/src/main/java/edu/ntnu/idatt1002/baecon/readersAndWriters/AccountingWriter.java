package edu.ntnu.idatt1002.baecon.readersAndWriters;

import edu.ntnu.idatt1002.baecon.data.AccountingEntry;
import edu.ntnu.idatt1002.baecon.utilities.BaeconDateFormatter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

/**
 * This class writes a {@code AccountingEntry} file.
 */
public class AccountingWriter {
  private final String delimiter = ",";
  private final String newline = "\n";

  /**
   * This method writes a {@code AccountingEntry} file.
   *
   * @param accountingEntry as {@code AccountingEntry}
   * @throws IOException "Unsupported file format. Only .csv files are supported."
   * @throws IOException "File does not exist. Unable to write to file that does not exist."
   * @throws IOException "Unable to write accounting entries to file " + file.getName() + "."
   */
  public void writeAccountingEntryToFile(AccountingEntry accountingEntry, File file)
      throws IOException {
    if (!file.getName().endsWith(".csv")) {
      throw new IOException("Unsupported file format. Only .csv files are supported.");
    }
    if (accountingEntry == null) {
      throw new NullPointerException("AccountingEntry cannot be null");
    }

    try {
      FileWriter fileWriter = new FileWriter(file, true);
      fileWriter.write(accountingEntry.getId() + delimiter + accountingEntry.isExpense()
          + delimiter + BaeconDateFormatter.format(accountingEntry.getDate()) + delimiter
          + accountingEntry.getAmount() + delimiter + accountingEntry.getCategoryId()
          + delimiter + accountingEntry.getDescription() + delimiter
          + accountingEntry.getReceiptId() + System.lineSeparator());
      fileWriter.close();
    } catch (IOException e) {
      throw new IOException("Unable to write accounting entries to file " + file.getName() + ".");
    }
  }

  /**
   * Method to write accounting entries to file.
   *
   * @param accountingEntries the accounting entries
   * @param file the file
   * @throws IOException io exception
   */
  public void writeAccountingEntriesToFile(List<AccountingEntry> accountingEntries, File file) throws IOException {
    checkIfFileIsValid(file);
    if (accountingEntries == null) {
      throw new IllegalArgumentException("AccountingEntries can not be null!");
    }

    try (FileWriter fileWriter = new FileWriter(file)) {
      accountingEntries.forEach(accountingEntry -> {
        try {
          fileWriter.write(accountingEntry.getId() + delimiter);
          fileWriter.write(accountingEntry.isExpense() + delimiter);
          fileWriter.write(BaeconDateFormatter.format(accountingEntry.getDate()) + delimiter);
          fileWriter.write(accountingEntry.getAmount() + delimiter);
          fileWriter.write(accountingEntry.getCategoryId() + delimiter);
          fileWriter.write(accountingEntry.getDescription() + delimiter);
          fileWriter.write(accountingEntry.getReceiptId() + "\n");
        } catch (IOException e) {
          throw new RuntimeException(e);
        }
      });
    }
  }

  private void checkIfFileIsValid(File file) throws IOException {
    if (!file.getName().endsWith(".csv")) {
      throw new IOException("Unsupported file format. Only .csv files are supported.");
    }
    if (!file.exists()) {
      throw new IOException("File does not exist. Unable to write to file that does not exist.");
    }
  }
}
