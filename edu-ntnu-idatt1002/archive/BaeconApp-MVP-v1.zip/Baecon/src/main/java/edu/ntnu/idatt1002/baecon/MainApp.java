package edu.ntnu.idatt1002.baecon;

public class MainApp {
  public static void main(String[] args) {
    BaeconApplication.main(args);
  }
}
