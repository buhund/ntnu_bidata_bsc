package edu.ntnu.idatt1002.baecon.data;

import java.io.File;
import java.util.Date;
import java.util.UUID;

/**
 * This class represents a receipt in the BigBærumEconomy program.
 *
 * @author Håkon R Billingstad
 */
public class Receipt {

  private final UUID id;
  private String description;
  private Date date;
  private File file;

  /**
   * This constructor creates a receipts object.
   *
   * @param description as String
   * @param date as {@code Date}
   * @param file as {@code File}
   */
  public Receipt(String description, Date date, File file) {
    this.id = UUID.randomUUID();
    setDescription(description);
    setDate(date);
    setPdfFile(file);
  }

  /**
   * This constructor creates a receipts object.
   *
   * @param id as UUID
   * @param description as String
   * @param date as {@code Date}
   * @param pdfFile as {@code File}
   */
  public Receipt(UUID id, String description, Date date, File pdfFile) {
    this.id = id;
    setDescription(description);
    setDate(date);
    setPdfFile(pdfFile);
  }

  /**
   * This method retrieves an ID from a {@code Receipt} object.
   *
   * @return ID as {@code UUID}
   */
  public UUID getId() {
    return id;
  }

  /**
   * This method retrieves a description from a {@code Receipt} object.
   *
   * @return description as String
   */
  public String getDescription() {
    return description;
  }

  /**
   * This method set a description on a {@code Receipt} object.
   *
   * @param description as String
   */
  public void setDescription(String description) {
    if (description == null) {
      throw new IllegalArgumentException("Description missing");
    }
    this.description = description;
  }

  /**
   * This method retrieves a date from a {@code Receipt} object.
   *
   * @return date as {@code Date}
   */
  public Date getDate() {
    return date;
  }

  /**
   * This method set a Date on a {@code Receipt} object.
   *
   * @param date as {@code Date}
   */
  public void setDate(Date date) {
    if (date == null) {
      throw new IllegalArgumentException("Date must be set!");
    }
    this.date = date;
  }

  /**
   * This method retrieves a file path from a {@code Receipt} object.
   *
   * @return file path as {@code File}
   */
  public File getPdfFile() {
    return file;
  }

  /**
   * This method set a file path on a {@code Receipt} object.
   *
   * @param file as {@code File}
   */
  public void setPdfFile(File file) {
    if (file == null) {
      throw new IllegalArgumentException("No file path defined");
    }
    this.file = file;
  }
}
