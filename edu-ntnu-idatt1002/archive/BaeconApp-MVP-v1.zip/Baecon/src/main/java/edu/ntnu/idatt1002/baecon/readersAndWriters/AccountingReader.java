package edu.ntnu.idatt1002.baecon.readersAndWriters;

import edu.ntnu.idatt1002.baecon.data.AccountingEntry;
import edu.ntnu.idatt1002.baecon.utilities.BaeconDateFormatter;
import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.util.UUID;

/**
 * This class reads {@code AccountingEntry} object from file
 */
public class AccountingReader {
  private final String delimiter = ",|" + System.lineSeparator();

  /**
   * This method reads a {@code AccountingEntry} file.
   *
   * @param file (File)
   * @return accountingEntries (List<AccountingEntry>)
   * @throws IOException "Unsupported file format. Only .csv files are supported."
   * @throws ParseException e
   * @throws IOException "Unable to read accounting entries from file " + file.getName() + "."
   */
  public List<AccountingEntry> readAllAccountingEntriesInAMonthFromFile(File file)
      throws IOException, ParseException {
    if (!file.getName().endsWith(".csv")) {
      throw new IOException("Unsupported file format. Only .csv files are supported.");
    }
    List<AccountingEntry> accountingEntries = new ArrayList<>();
    try {
    Scanner accountingEntryFileReader = new Scanner(file);
    accountingEntryFileReader.useDelimiter(delimiter);
    while (accountingEntryFileReader.hasNext()) {

      String idAsString = accountingEntryFileReader.next();
      UUID id = UUID.fromString(idAsString);

      boolean expense = Boolean.parseBoolean(accountingEntryFileReader.next());

      Date formatDate = BaeconDateFormatter.parse(accountingEntryFileReader.next());

      double amount = Double.parseDouble(accountingEntryFileReader.next());

      String categoryIdAsString = accountingEntryFileReader.next();
      UUID categoryId = UUID.fromString(categoryIdAsString);

      String description = accountingEntryFileReader.next();

      String pdfIdAsString = accountingEntryFileReader.next();
      UUID pdfId;
      if (pdfIdAsString.equals("null")) {
        pdfId = null;
      } else {
        pdfId = UUID.fromString(pdfIdAsString);
      }

      AccountingEntry accountingEntry = new AccountingEntry(id, expense,
          formatDate, amount, categoryId, description, pdfId);
      accountingEntries.add(accountingEntry);
    }
    accountingEntryFileReader.close();
  } catch (IOException e) {
    throw new IOException("Unable to read accounting entries from file " + file.getName() + ".");
  } catch (ParseException e) {
    throw new ParseException(e.getMessage(), e.getErrorOffset());
  }
    return accountingEntries;
  }
}
