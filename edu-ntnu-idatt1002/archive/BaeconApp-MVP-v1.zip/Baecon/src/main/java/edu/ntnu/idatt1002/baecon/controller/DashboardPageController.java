package edu.ntnu.idatt1002.baecon.controller;

import edu.ntnu.idatt1002.baecon.data.AccountingEntry;
import edu.ntnu.idatt1002.baecon.data.BudgetEntry;
import edu.ntnu.idatt1002.baecon.data.Category;
import edu.ntnu.idatt1002.baecon.listeners.AccountingEntriesChangeListener;
import edu.ntnu.idatt1002.baecon.listeners.BudgetEntriesChangeListener;
import edu.ntnu.idatt1002.baecon.listeners.CategoriesChangeListener;
import edu.ntnu.idatt1002.baecon.readersAndWriters.AccountingReader;
import edu.ntnu.idatt1002.baecon.readersAndWriters.BudgetReader;
import edu.ntnu.idatt1002.baecon.readersAndWriters.CategoryReader;
import java.io.File;
import java.io.IOException;
import java.security.PrivateKey;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.LineChart;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;


public class DashboardPageController implements AccountingEntriesChangeListener, BudgetEntriesChangeListener, CategoriesChangeListener{

  @FXML private LineChart trendChart;
  @FXML private BarChart overviewChart;
  @FXML private ComboBox monthPicker;
  @FXML private ComboBox yearPicker;

  @FXML private TableView<tableViewRow> overviewView;
  @FXML private TableColumn<tableViewRow, String> categoryName;
  @FXML private TableColumn<tableViewRow, String> budgeted;
  @FXML private TableColumn<tableViewRow, String> spent;
  @FXML private TableColumn<tableViewRow, String> result;

  List<Category> categories;
  List<BudgetEntry> budgetEntries;
  List<AccountingEntry> accountingEntries;

  private AccountingEntriesController accountingEntriesController;
  private BudgetEntriesController budgetEntriesController;
  private CategoriesController categoriesController;
  private BudgetPageController budgetPageController;



  public DashboardPageController() {
  }

  @FXML
  public void initialize() throws IOException, ParseException {


    categoriesController = CategoriesController.getInstance();
    categoriesController.addSubscriber(this);

    accountingEntriesController = AccountingEntriesController.getInstance();
    accountingEntriesController.addSubscriber(this);

    budgetEntriesController = BudgetEntriesController.getInstance();
    budgetEntriesController.addSubscriber(this);

    this.categories = categoriesController.getCategories();
    this.budgetEntries = budgetEntriesController.getBudgetEntries();
    this.accountingEntries = accountingEntriesController.getAccountingEntries();

    categoryName.setCellValueFactory(new PropertyValueFactory<tableViewRow, String>("category"));
    budgeted.setCellValueFactory(new PropertyValueFactory<tableViewRow, String>("budgeted"));
    spent.setCellValueFactory(new PropertyValueFactory<tableViewRow, String>("spent"));
    result.setCellValueFactory(new PropertyValueFactory<tableViewRow, String>("result"));

    monthPicker.getItems().addAll("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
    monthPicker.valueProperty().addListener(new ChangeListener() {
      @Override
      public void changed(ObservableValue observableValue, Object o, Object t1) {
        switch ((String)t1) {
          case "January" -> accountingEntriesController.loadEntries("01", "2023");
          case "February" -> accountingEntriesController.loadEntries("02", "2023");
          case "March" -> accountingEntriesController.loadEntries("03", "2023");
          case "April" -> accountingEntriesController.loadEntries("04", "2023");
          case "May" -> accountingEntriesController.loadEntries("05", "2023");
          case "June" -> accountingEntriesController.loadEntries("06", "2023");
          case "July" -> accountingEntriesController.loadEntries("07", "2023");
          case "August" -> accountingEntriesController.loadEntries("08", "2023");
          case "September" -> accountingEntriesController.loadEntries("09", "2023");
          case "October" -> accountingEntriesController.loadEntries("10", "2023");
          case "November" -> accountingEntriesController.loadEntries("11", "2023");
          case "December" -> accountingEntriesController.loadEntries("12", "2023");

        }

        }
      });

    getTableData();
  }

  public void getTableData() {

    for (Category category : categories) {
      double totalSpent = 0.0;
      double budgeted = 0.0;
      BudgetEntry budgetEntry = budgetEntries.stream().filter(budgetEntry1 -> budgetEntry1.getCategoryId().equals(category.getId())).findFirst().orElse(null);
      if (budgetEntry != null) {
        budgeted = budgetEntry.getAmount();
      }
      for (AccountingEntry accountingEntry : accountingEntries) {
        if (category.getId().equals(accountingEntry.getCategoryId())) {
          totalSpent += accountingEntry.getAmount();
        }
      }
      double result = budgeted - totalSpent;
      overviewView.getItems().add(new tableViewRow(category.getName(), budgeted, totalSpent, result));
    }
  }

  public class tableViewRow{
    String category;
    Double budgeted;
    Double spent;
    Double result;


    public tableViewRow(String category, Double budgeted, Double spent, Double result) {
      this.category = category;
      this.budgeted = budgeted;
      this.spent = spent;
      this.result = result;
    }

    public String getCategory() {
      return category;
    }

    public Double getBudgeted() {
      return budgeted;
    }

    public Double getSpent() {
      return spent;
    }

    public Double getResult() {
      return result;
    }




  }



  // TODO Sum accounting entries by category and pop into table
  // TODO Pop budget entries into table
  // TODO Compare Budget and Accounting by category and sum

  private void loadAccountingEntries () {
    // TODO Load accounting entries
  }

  private void loadBudgetEntries() {
    // TODO Load budget entries
  }

  @FXML
  void onPickMonth(int month) {
    //accountingEntriesController.loadEntries(String.format("%02d", month), "2023");
    //budgetEntriesController.loadEntries(String.format("%02d", month), "2023");
    // TODO Show entries based on month/year picker

  }


  @FXML
  void onPickYear(int year) {
    // TODO onPickYear
  }


  @Override
  public void updateAccountingEntries(List<AccountingEntry> accountingEntries) {
    this.accountingEntries = accountingEntries;
    overviewView.getItems().clear();
    getTableData();
  }

  @Override
  public void update(List<BudgetEntry> budgetEntries) {

  }

  @Override
  public void updateCategories(List<Category> categories) {

  }
}

