package edu.ntnu.idatt1002.baecon.controller;

import edu.ntnu.idatt1002.baecon.data.AccountingEntry;
import edu.ntnu.idatt1002.baecon.data.Category;
import edu.ntnu.idatt1002.baecon.listeners.AccountingEntriesChangeListener;
import edu.ntnu.idatt1002.baecon.listeners.CategoriesChangeListener;
import edu.ntnu.idatt1002.baecon.readersAndWriters.AccountingReader;
import edu.ntnu.idatt1002.baecon.readersAndWriters.CategoryReader;
import edu.ntnu.idatt1002.baecon.scenes.View;
import edu.ntnu.idatt1002.baecon.scenes.ViewSwitcher;
import java.io.IOException;
import java.util.List;
import java.util.Objects;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 * Class responsible for setting up and
 */
public class AccountingPageController implements AccountingEntriesChangeListener,
  CategoriesChangeListener {
  @FXML private VBox accountingEntriesView;
  @FXML private VBox monthsPicker;
  private AccountingEntriesController accountingEntriesController;
  private CategoriesController categoriesController;
  @FXML
  public void initialize() {
    categoriesController = CategoriesController.getInstance();
    categoriesController.addSubscriber(this);
    accountingEntriesController = AccountingEntriesController.getInstance();
    accountingEntriesController.addSubscriber(this);

    int i = 1;
    for (Node node : monthsPicker.getChildren()) {
      Button monthPicker = (Button) node;
      int finalI = i;
      monthPicker.setOnAction(actionEvent -> {
        onPickMonth(finalI);
      });
      i++;
    }

    // Load into view
    showAccountingEntries(accountingEntriesController.getAccountingEntries());
  }

  private void showAccountingEntries(List<AccountingEntry> accountingEntries) {
    accountingEntriesView.getChildren().clear();
    if (accountingEntries.size() == 0) {
      accountingEntriesView.getChildren().add(new Text("No entries..."));
      return;
    }
    accountingEntries.forEach(accountingEntry -> {
      try {
        loadAccountingEntry(accountingEntry);
      } catch (IOException e) {
        throw new RuntimeException(e);
      }
    });
  }

  @FXML
  void onAddNewIncome() throws IOException {
    Stage newIncomeStage = new Stage();
    newIncomeStage.setTitle("Baecon - Add income");
    FXMLLoader addToAccountingFXML = new FXMLLoader(Objects.requireNonNull(ViewSwitcher.class
      .getResource(View.ADD_TO_ACCOUNTING.getFileName())));
    addToAccountingFXML.load();

    AddAccountingEntryController addAccountingEntryController = addToAccountingFXML.getController();
    addAccountingEntryController.initData(false, newIncomeStage);


    newIncomeStage.setScene(new Scene(addToAccountingFXML.getRoot()));
    newIncomeStage.show();
  }

  @FXML
  void onAddNewExpense() throws IOException {
    Stage newExpenseStage = new Stage();
    newExpenseStage.setTitle("Baecon - Add expense");
    FXMLLoader addToAccountingFXML = new FXMLLoader(Objects.requireNonNull(ViewSwitcher.class
      .getResource(View.ADD_TO_ACCOUNTING.getFileName())));
    addToAccountingFXML.load();

    AddAccountingEntryController addAccountingEntryController = addToAccountingFXML.getController();
    addAccountingEntryController.initData(true, newExpenseStage);


    newExpenseStage.setScene(new Scene(addToAccountingFXML.getRoot()));
    newExpenseStage.show();
  }

  // TODO: write javadoc
  // TODO: better error handling
  @FXML
  void onPickMonth(int month) {
    accountingEntriesController.loadEntries(String.format("%02d", month), "2023");
  }


  private void loadAccountingEntry(AccountingEntry accountingEntry) throws IOException {
    FXMLLoader accountingEntryFXML = new FXMLLoader(Objects.requireNonNull(ViewSwitcher.class
      .getResource("accountingEntry.fxml")));
    accountingEntryFXML.load();

    AccountingEntryController accountingEntryController = accountingEntryFXML.getController();
    accountingEntryController.initData(accountingEntry);

    accountingEntriesView.getChildren().add(accountingEntryFXML.getRoot());
  }

  @Override
  public void updateAccountingEntries(List<AccountingEntry> accountingEntries) {
    showAccountingEntries(accountingEntries);
  }

  @Override
  public void updateCategories(List<Category> categories) {
    showAccountingEntries(accountingEntriesController.getAccountingEntries());
  }
}
