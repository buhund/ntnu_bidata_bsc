package edu.ntnu.idatt1002.baecon.scenes;

import java.io.IOException;
import java.util.Objects;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;

public class ViewSwitcher {
  private static Scene scene;
  private static BorderPane generalLayout = null;

  public static void setScene(Scene scene) throws IOException {
    ViewSwitcher.scene = scene;
  }

  public static void switchTo(View view) throws IOException {
    try {
      if (generalLayout == null) {
        generalLayout = FXMLLoader.load(Objects.requireNonNull(ViewSwitcher.class
          .getResource("generalLayout.fxml")));
      }
      Parent root = FXMLLoader.load(Objects.requireNonNull(ViewSwitcher.class
        .getResource(view.getFileName())));
      generalLayout.setCenter(root);
      scene.setRoot(generalLayout);
    } catch (IOException ioException) {
      ioException.printStackTrace();
    }
  }
}
