package edu.ntnu.idatt1002.baecon.listeners;

import edu.ntnu.idatt1002.baecon.data.AccountingEntry;
import java.util.List;

public interface AccountingEntriesChangeListener {
  void updateAccountingEntries(List<AccountingEntry> accountingEntries);
}
