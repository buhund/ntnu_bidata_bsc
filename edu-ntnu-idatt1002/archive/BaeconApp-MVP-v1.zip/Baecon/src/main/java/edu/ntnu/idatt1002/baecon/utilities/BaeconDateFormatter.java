package edu.ntnu.idatt1002.baecon.utilities;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Helper class to format and parse dates with our own format.
 */
public class BaeconDateFormatter {
  private static final String dateFormat = "dd.MM.yyyy HH:mm:ss";

  /**
   * Method to format a string from a date.
   *
   * @param dateToFormat date to format
   * @return the date formatted as a string
   */
  public static String format(Date dateToFormat) {
    SimpleDateFormat dateFormatter = new SimpleDateFormat(BaeconDateFormatter.dateFormat);
    return dateFormatter.format(dateToFormat);
  }

  /**
   * Method to parse a date from a string.
   *
   * @param dateString date as string
   * @return the string as a Date
   * @throws ParseException parse exception
   */
  public static Date parse(String dateString) throws ParseException {
    SimpleDateFormat dateFormatter = new SimpleDateFormat(BaeconDateFormatter.dateFormat);
    return dateFormatter.parse(dateString);
  }
}
