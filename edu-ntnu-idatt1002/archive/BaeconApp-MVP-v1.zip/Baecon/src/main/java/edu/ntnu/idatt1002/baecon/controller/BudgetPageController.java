package edu.ntnu.idatt1002.baecon.controller;

import edu.ntnu.idatt1002.baecon.data.BudgetEntry;
import edu.ntnu.idatt1002.baecon.data.Category;
import edu.ntnu.idatt1002.baecon.listeners.BudgetEntriesChangeListener;
import edu.ntnu.idatt1002.baecon.readersAndWriters.BudgetReader;
import edu.ntnu.idatt1002.baecon.readersAndWriters.CategoryReader;
import edu.ntnu.idatt1002.baecon.scenes.View;
import edu.ntnu.idatt1002.baecon.scenes.ViewSwitcher;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Objects;

public class BudgetPageController implements BudgetEntriesChangeListener {
  @FXML private VBox incomeBudgetEntriesView;
  @FXML private VBox expenseBudgetEntriesView;

  /**
   * The controller for the budget entries.
   */
  private BudgetEntriesController budgetEntriesController;

  /**
   * The controller for the categories.
   *
   * @throws IOException
   */
  @FXML
  public void initialize() throws IOException {
    budgetEntriesController = BudgetEntriesController.getInstance();
    budgetEntriesController.addSubscriber( this);

    showBudgetEntries(budgetEntriesController.getBudgetEntries());
  }

  /**
   * This method loads a budget entry into the view.
   *
   * @param budgetEntries {@code List} of {@code BudgetEntry}
   */
  private void showBudgetEntries(List<BudgetEntry> budgetEntries) {
    incomeBudgetEntriesView.getChildren().clear();
    expenseBudgetEntriesView.getChildren().clear();

    if (budgetEntries.size() == 0) {
      incomeBudgetEntriesView.getChildren().add(new Text("No entries..."));
      expenseBudgetEntriesView.getChildren().add(new Text("No entries..."));
      return;
    }

    budgetEntries.forEach(budgetEntry -> {
      try {
        loadBudgetEntry(budgetEntry);
      } catch (IOException e) {
        throw new RuntimeException(e);
      }
    });
  }

  /**
   * This method loads an add income entry into the view.
   *
   * @throws IOException io exception
   */
  @FXML
  void onAddNewInCome() throws IOException {
    Stage newIncomeStage = new Stage();
    newIncomeStage.setTitle("Baecon - Add income");
    FXMLLoader addToBudgetFXML = new FXMLLoader(Objects.requireNonNull(ViewSwitcher.class.
            getResource(View.ADD_TO_BUDGET.getFileName())));
    addToBudgetFXML.load();

    AddBudgetEntryController addBudgetEntryController = addToBudgetFXML.getController();
    addBudgetEntryController.initData(false, newIncomeStage);


    newIncomeStage.setScene(new Scene(addToBudgetFXML.getRoot()));
    newIncomeStage.show();
  }

  /**
   * This method loads an add expense entry into the view.
   *
   * @throws IOException io exception
   */
  @FXML
  void onAddNewExpense() throws IOException {
    Stage newExpenseStage = new Stage();
    newExpenseStage.setTitle("Baecon - Add expense");
    System.out.println("New expense");
    FXMLLoader addToBudgetFXML = new FXMLLoader(Objects.requireNonNull(ViewSwitcher.class.
            getResource(View.ADD_TO_BUDGET.getFileName())));
    addToBudgetFXML.load();

    AddBudgetEntryController addBudgetEntryController = addToBudgetFXML.getController();
    addBudgetEntryController.initData(true, newExpenseStage);

    newExpenseStage.setScene(new Scene(addToBudgetFXML.getRoot()));
    newExpenseStage.show();
  }

  /**
   * This method loads a budget entry into the view.
   *
   * @param budgetEntry budgetEntry as {@code BudgetEntry}
   * @throws IOException io exception
   */
  private void loadBudgetEntry(BudgetEntry budgetEntry) throws IOException {
    FXMLLoader budgetEntryFXML = new FXMLLoader(Objects.requireNonNull(ViewSwitcher.class.
            getResource("budgetEntry.fxml")));
    budgetEntryFXML.load();

    BudgetEntryController budgetEntryController = budgetEntryFXML.getController();
    budgetEntryController.initBudgetEntryData(budgetEntry);

    if (!budgetEntry.isExpense()) {
      incomeBudgetEntriesView.getChildren().add(budgetEntryFXML.getRoot());
    } else {
      expenseBudgetEntriesView.getChildren().add(budgetEntryFXML.getRoot());
    }
  }

  /**
   * This method updates the budget entries.
   * @param budgetEntries as {@code List} of {@code BudgetEntry}
   */
  @Override
  public void update(List<BudgetEntry> budgetEntries) {
    showBudgetEntries(budgetEntries);
  }
}
