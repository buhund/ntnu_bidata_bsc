package edu.ntnu.idatt1002.baecon.readersAndWriters;

import edu.ntnu.idatt1002.baecon.data.BudgetEntry;
import edu.ntnu.idatt1002.baecon.data.Category;
import edu.ntnu.idatt1002.baecon.utilities.BaeconDateFormatter;
import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.util.UUID;

/**
 * This class reads {@code BudgetEntry} object from a file
 */
public class BudgetReader {
  private final String delimiter = ",|" + System.lineSeparator();

  /**
   * This method reads a {@code BudgetEntry} file.
   *
   * @param file (File)
   * @return a list of budget entries (List<BudgetEntry>)
   * @throws IOException "Unsupported file format. Only .csv files are supported."
   * @throws IOException "Unable to read budget entries from file " + file.getName() + "."
   */
  public List<BudgetEntry> readAllBudgetEntriesInAMonthFromFile(File file)
      throws IOException {
    if (!file.getName().endsWith(".csv")) {
      throw new IOException("Unsupported file format. Only .csv files are supported.");
    }
    List<BudgetEntry> budgetEntries = new ArrayList<>();
    try {
      Scanner budgetEntryFileReader = new Scanner(file);
      budgetEntryFileReader.useDelimiter(delimiter);
      while (budgetEntryFileReader.hasNext()) {

        String idAsString = budgetEntryFileReader.next();
        UUID id = UUID.fromString(idAsString);

        boolean expense = Boolean.parseBoolean(budgetEntryFileReader.next());

        double amount = Double.parseDouble(budgetEntryFileReader.next());

        String categoryIdAsString = budgetEntryFileReader.next();
        UUID categoryId = UUID.fromString(categoryIdAsString);

        BudgetEntry budgetEntry = new BudgetEntry(id, expense, amount, categoryId);
        budgetEntries.add(budgetEntry);
      }
      budgetEntryFileReader.close();
    } catch (IOException e) {
      throw new IOException("Unable to read budget entries from file " + file.getName() + ".");
    }
    return budgetEntries;
  }
}
