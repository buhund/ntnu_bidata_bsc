package edu.ntnu.idatt1002.baecon.scenes;

public enum View {
  DASHBOARD("dashboardPage.fxml"),
  BUDGET("budgetPage.fxml"),
  ACCOUNTING("accountingPage.fxml"),
  ADD_TO_BUDGET("addBudgetEntry.fxml"),
  ADD_TO_ACCOUNTING("addAccountingEntry.fxml"),
  RECEIPTS("receiptsPage.fxml"),
  SETTINGS("settingsPage.fxml"),
  SETTINGS_CATEGORY_ENTRY("settingsCategoryDialog.fxml");


  private String fileName;

  View(String fileName) {
    this.fileName = fileName;
  }

  public String getFileName() {
    return fileName;
  }
}
