package edu.ntnu.idatt1002.baecon.controller;

import edu.ntnu.idatt1002.baecon.data.Category;
import edu.ntnu.idatt1002.baecon.listeners.CategoriesChangeListener;
import edu.ntnu.idatt1002.baecon.readersAndWriters.CategoryReader;
import edu.ntnu.idatt1002.baecon.readersAndWriters.CategoryWriter;
import java.io.File;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

/**
 * Class responsible for handling categories.
 */
public class CategoriesController {
  private static CategoriesController instance = null;
  private List<CategoriesChangeListener> listeners;
  private HashMap<UUID, Category> categories;
  private CategoryReader categoryReader = new CategoryReader();
  private CategoryWriter categoryWriter = new CategoryWriter();

  /**
   * Constructor for instantiating a new CategoriesController.
   */
  private CategoriesController() {
    listeners = new ArrayList<>();
    loadCategoriesFromFile();
  }

  /**
   * Method to get the instance of a CategoriesController.
   *
   * @return the instance of
   */
  public static CategoriesController getInstance() {
    if (instance == null) {
      instance = new CategoriesController();
    }
    return instance;
  }

  /**
   * Method to load categories from file.
   */
  public void loadCategoriesFromFile() {
    try {
      File file = new File("src/main/resources/edu/ntnu/idatt1002/baecon/dataFiles/categories.csv");
      categories = (HashMap<UUID, Category>) categoryReader.readAllCategoriesFromFile(file);
    } catch (IOException ioException) {
      System.out.println(ioException.getMessage());
    }
  }

  /**
   * Method to get the categories.
   *
   * @return a list of {@code Category}
   */
  public List<Category> getCategories() {
    return categories.values().stream().toList();
  }

  /**
   * Method to get a {@code Category} by {@code categoryId}.
   *
   * @param categoryId the categoryId
   * @return the Category with the given id
   */
  public Category getCategoryById(UUID categoryId) {
    return categories.get(categoryId);
  }

  /**
   * Method to get a {@code Category} by {@code description}.
   *
   * @param description the description of the Category
   * @return the Category with the given description
   */
  public Category getCategoryByDescription(String description) {
    return categories
      .values()
      .stream()
      .filter(category -> category.getName().equals(description))
      .findFirst()
      .orElse(null);
  }

  /**
   * Method to add a new {@code Category}.
   *
   * @param category the category
   */
  public void addCategory(Category category) {
    try {
      File file = new File(FileSystems.getDefault().getPath("src", "main", "resources",
        "edu/ntnu/idatt1002/baecon/dataFiles/categories.csv").toUri());
      categoryWriter.writeCategoryToFile(category, file);
      categories.put(category.getId(), category);
      listeners.forEach(listener -> listener.updateCategories(getCategories()));
    } catch (IOException ioException) {
      System.out.println(ioException.getMessage());
    }
  }

  /**
   * Method to add a new subscriber to the list of listeners.
   *
   * @param listener the new listener.
   */
  public void addSubscriber(CategoriesChangeListener listener) {
    listeners.add(listener);
  }

  /**
   * Method to remove a subscriber from the list of listeners.
   *
   * @param listener the listener
   */
  public void removeSubscriber(CategoriesChangeListener listener) {
    listeners.remove(listener);
  }
}
