package edu.ntnu.idatt1002.baecon.readersAndWriters;

import edu.ntnu.idatt1002.baecon.data.BudgetEntry;
import edu.ntnu.idatt1002.baecon.utilities.BaeconDateFormatter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

/**
 * This class writes a {@code BudgetEntry} file.
 */
public class BudgetWriter {
  private final String delimiter = ",";

  /**
   * This method writes a {@code BudgetEntry} file.
   *
    * @param budgetEntry as {@code BudgetEntry}
   * @throws IOException "Unsupported file format. Only .csv files are supported."
   * @throws IOException "File does not exist. Unable to write to file that does not exist."
   * @throws IOException "Unable to write budget entries to file " + file.getName() + "."
   */
 public void writeBudgetEntryToFile (BudgetEntry budgetEntry, File file) throws IOException {
   if (!file.getName().endsWith(".csv")) {
     throw new IOException("Unsupported file format. Only .csv files are supported.");
   }
   if (!file.exists()) {
     throw new IOException("File does not exist. Unable to write to file that does not exist.");
   }
   try {
     FileWriter fileWriter = new FileWriter(file, true);
     fileWriter.write(budgetEntry.getId() + delimiter + budgetEntry.isExpense() + delimiter + budgetEntry.getAmount()
         + delimiter + budgetEntry.getCategoryId() + System.lineSeparator());
     fileWriter.close();
   } catch (IOException e) {
     throw new IOException("Unable to write budget entries to file " + file.getName() + ".");
   }
 }
}
