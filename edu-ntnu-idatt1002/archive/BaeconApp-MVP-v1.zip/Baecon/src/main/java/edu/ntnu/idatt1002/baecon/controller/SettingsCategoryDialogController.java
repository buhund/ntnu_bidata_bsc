package edu.ntnu.idatt1002.baecon.controller;


import edu.ntnu.idatt1002.baecon.data.Category;
import java.io.IOException;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.scene.text.Text;


public class SettingsCategoryDialogController {

  @FXML
  private Text titleCategoryDialogText;
  @FXML private TextField categoryNameTextField;
  @FXML
  private Button applyButton;
  @FXML
  private Button cancelButton;


  private boolean isNewCategory;
  private Stage currentStage;

  @FXML
  public void initialize() throws IOException {
    // TODO Make stuff


  }


  // TODO Actually make the title text change according to New and Edit
  public void initData(boolean isNewCategory, Stage currentStage) {
    this.isNewCategory = isNewCategory;
    this.currentStage = currentStage;
    titleCategoryDialogText.setText((isNewCategory ? "New" : "Edit") + " Category");
  }


  @FXML
  void onCancelCategoryButton () {
    // TODO Make stuff
  }
  @FXML
  void onApplyCategoryButton () {
    // TODO Make stuff
    if (isNewCategory) {
      // Save
      Category category = new Category(categoryNameTextField.getText());
      CategoriesController.getInstance().addCategory(category);
      currentStage.close();
    }
  }

}