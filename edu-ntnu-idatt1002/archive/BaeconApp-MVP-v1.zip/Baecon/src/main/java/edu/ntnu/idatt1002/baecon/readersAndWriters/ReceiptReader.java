package edu.ntnu.idatt1002.baecon.readersAndWriters;

import edu.ntnu.idatt1002.baecon.data.Receipt;
import edu.ntnu.idatt1002.baecon.utilities.BaeconDateFormatter;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * This class reads {@code Receipt} object from a file.
 */
public class ReceiptReader {

  private final String delimiter = ",|" + System.lineSeparator();

  /**
   * This method reads all Receipts from a file.
   *
   * @return a list of {@code Receipt}
   * @throws IOException if the file is not found.
   * @throws ParseException if date is in wrong format.
   */
  public List<Receipt> readAllReceiptsFromFile(File filePath) throws IOException, ParseException {
    if (!filePath.getName().endsWith(".csv")) {
      throw new IOException("Unsupported file format. Only .csv files are supported.");
    }
    List<Receipt> receipts = new ArrayList<>();
    try {
      Scanner receiptFileReader = new Scanner((filePath));
      receiptFileReader.useDelimiter(delimiter);
      while (receiptFileReader.hasNext()) {

        String idAsString = receiptFileReader.next();
        UUID id = UUID.fromString(idAsString);

        String description = receiptFileReader.next();

        Date formatedDate = BaeconDateFormatter.parse(receiptFileReader.next());

        File PdfFilePath = new File(receiptFileReader.next());

        Receipt receipt = new Receipt(id, description, formatedDate , PdfFilePath);

        receipts.add(receipt);
      }
      receiptFileReader.close();
    } catch (IOException e) {
      throw new IOException("File is not found");
    }catch (ParseException e) {
      throw new ParseException(e.getMessage(), e.getErrorOffset());
    }
    return receipts;
  }
}
