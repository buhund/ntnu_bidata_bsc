package edu.ntnu.idatt1002.baecon.readersAndWriters;

import edu.ntnu.idatt1002.baecon.data.Receipt;
import edu.ntnu.idatt1002.baecon.utilities.BaeconDateFormatter;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

/**
 * This class writes a {@code Receipt} file.
 */
public class ReceiptWriter {

  private final String delimiter = ",";

  /**
   * This method writes a {@code Receipt} file.
   *
   * @param receipt as {@code Receipt}
   * @throws IOException
   */
  public void writeReceiptToFile (Receipt receipt, File file) throws IOException {
    if (!file.getName().endsWith(".csv")) {
      throw new IOException("Unsupported file format. Only .csv files are supported.");
    }
    if (!file.exists()) {
      throw new IOException("File does not exist. Unable to write to file that does not exist.");
    }
    try {
      FileWriter fileWriter = new FileWriter(file, true);
      fileWriter.write(receipt.getId() + delimiter + receipt.getDescription() + delimiter + BaeconDateFormatter.format(receipt.getDate()) +
               delimiter + receipt.getPdfFile() + System.lineSeparator());
      fileWriter.close();
    } catch (IOException e) {
      throw new IOException("Unable to find file.");
    }
  }
}
