package edu.ntnu.idatt1002.baecon.controller;

import edu.ntnu.idatt1002.baecon.scenes.View;
import edu.ntnu.idatt1002.baecon.scenes.ViewSwitcher;
import java.io.IOException;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class GeneralLayoutController {
  @FXML private Button dashboardButton;
  @FXML private Button budgetButton;
  @FXML private Button accountingButton;
  @FXML private Button receiptsButton;
  @FXML private Button settingsButton;

  @FXML
  public void onClickDashboard() throws IOException {
    ViewSwitcher.switchTo(View.DASHBOARD);
  }

  @FXML
  public void onClickBudget() throws IOException {
    ViewSwitcher.switchTo(View.BUDGET);
  }

  @FXML
  public void onClickAccounting() throws IOException {
    ViewSwitcher.switchTo(View.ACCOUNTING);
  }

  @FXML
  public void onClickReceipts() throws IOException {
    ViewSwitcher.switchTo(View.RECEIPTS);
  }

  @FXML
  public void onClickSettings() throws IOException {
    ViewSwitcher.switchTo(View.SETTINGS);
  }
}
