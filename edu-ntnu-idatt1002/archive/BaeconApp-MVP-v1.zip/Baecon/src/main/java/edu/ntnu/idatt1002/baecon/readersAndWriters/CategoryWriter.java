package edu.ntnu.idatt1002.baecon.readersAndWriters;

import edu.ntnu.idatt1002.baecon.data.Category;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

/**
 * Writes a category to a file.
 */
public class CategoryWriter {
  private final String delimiter = ",";

  /**
   * Writes a category to a file.
   * @param category
   * @throws IOException if an I/O error occurs
   */
  public void writeCategoryToFile(Category category, File file) throws IOException {
    if (!file.getName().endsWith(".csv")) {
      throw new IOException("Unsupported file format. Only .csv files are supported.");
    }
    if (!file.exists()) {
      throw new IOException("File does not exist. Unable to write to file that does not exist.");
    }
    try {
      FileWriter fileWriter = new FileWriter(file, true);
      fileWriter.write(category.getId() + delimiter + category.getName() + System.lineSeparator());
      fileWriter.close();
    } catch (IOException e) {
      throw new IOException("Unable to write categories to file " + file.getName() + ".");
    }
  }
}
