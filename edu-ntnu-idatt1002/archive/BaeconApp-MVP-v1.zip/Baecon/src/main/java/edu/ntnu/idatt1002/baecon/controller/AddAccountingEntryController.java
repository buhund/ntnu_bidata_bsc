package edu.ntnu.idatt1002.baecon.controller;

import edu.ntnu.idatt1002.baecon.data.AccountingEntry;
import edu.ntnu.idatt1002.baecon.data.Category;
import edu.ntnu.idatt1002.baecon.readersAndWriters.ReceiptWriter;
import java.io.File;
import java.io.IOException;
import java.time.ZoneId;
import java.util.Date;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class AddAccountingEntryController {
  @FXML private Text titleEntryText;
  @FXML private DatePicker datePicker;
  @FXML private TextField textFieldAmount;
  @FXML private TextArea descriptionTextArea;
  @FXML private ComboBox categoriesComboBox;
  @FXML private Button chooseFileButton;
  @FXML private CheckBox repeatCheckBox;
  @FXML private ComboBox repeatComboBox;
 //TODO: add week, quarter, month, year choices
  @FXML private Button addEntryButton;

  private ReceiptWriter receiptWriter = new ReceiptWriter();
  private boolean isExpense;
  private Stage currentStage;

  private AccountingEntriesController accountingEntriesController;


  @FXML
  public void initialize() throws IOException {
    accountingEntriesController = AccountingEntriesController.getInstance();

    CategoriesController.getInstance().getCategories().forEach(category -> {
      categoriesComboBox.getItems().add(category.getName());
    });
  }

  /**
   * Method to init accounting view with isExpense as a variable.
   *
   * @param isExpense is expense
   */
  public void initData(boolean isExpense, Stage currentStage) {
    this.isExpense = isExpense;
    this.currentStage = currentStage;
    titleEntryText.setText("New " + (isExpense ? "expense" : "income"));
    addEntryButton.setText("Add " + (isExpense ? "expense" : "income"));
  }

  @FXML
  public void addNewAccountingEntry() {
    try {
      Date date = Date.from(datePicker.getValue().atStartOfDay(ZoneId.systemDefault()).toInstant());
      Double amount = Double.parseDouble(textFieldAmount.getText());
      String description = descriptionTextArea.getText();
      Category chosenCategory = CategoriesController.getInstance()
        .getCategoryByDescription(categoriesComboBox.getValue().toString());

      chooseFileButton.setOnAction(event -> {

      });

      AccountingEntry accountingEntry = new AccountingEntry(isExpense, date, amount,
          chosenCategory.getId(), description, null);
      accountingEntriesController.addNewAccountingEntry(accountingEntry);
      currentStage.close();
    } catch (IllegalArgumentException | IOException numberFormatException) {
      System.out.println(numberFormatException.getMessage());
    }
  }

  private void fileChooser() {
    FileChooser fileChooser = new FileChooser();
    fileChooser.setTitle("Choose receipt file");
    File file = fileChooser.showOpenDialog(currentStage);
    if (file != null) {

    }
  }
}
