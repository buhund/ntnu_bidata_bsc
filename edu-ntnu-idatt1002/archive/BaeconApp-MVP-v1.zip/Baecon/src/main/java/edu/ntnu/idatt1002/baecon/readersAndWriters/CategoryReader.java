package edu.ntnu.idatt1002.baecon.readersAndWriters;

import edu.ntnu.idatt1002.baecon.data.Category;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;
import java.util.UUID;

/**
 * Reads all categories from a file.
 */
public class CategoryReader {
  private final String delimiter = ",|" + System.lineSeparator();

  /**
   * Reads all categories from a file.
   * @return a list of categories.
   * @throws IOException if an I/O error occurs.
   */
  public HashMap<UUID, Category> readAllCategoriesFromFile(File file) throws IOException {
    if (!file.getName().endsWith(".csv")) {
      throw new IOException("Unsupported file format. Only .csv files are supported.");
    }
    HashMap<UUID, Category> categories = new HashMap<>();
    try {
      Scanner fileReader = new Scanner(file);
      fileReader.useDelimiter(delimiter);
      while (fileReader.hasNext()) {
        String idAsString = fileReader.next();
        UUID id = UUID.fromString(idAsString);
        String description = fileReader.next();
        Category category = new Category(id, description);
        categories.put(id, category);
      }
      fileReader.close();
    } catch (IOException e) {
      throw new IOException("Unable to read categories from file " + file.getName() + ".");
    }
    return categories;
  }
}
