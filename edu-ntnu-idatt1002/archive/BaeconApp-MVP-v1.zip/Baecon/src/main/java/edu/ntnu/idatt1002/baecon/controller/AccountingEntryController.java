package edu.ntnu.idatt1002.baecon.controller;

import edu.ntnu.idatt1002.baecon.data.AccountingEntry;
import edu.ntnu.idatt1002.baecon.data.Category;
import edu.ntnu.idatt1002.baecon.utilities.BaeconDateFormatter;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.text.Text;

/**
 * Class responsible for setting up accountingEntryFXML.
 */
public class AccountingEntryController {
  @FXML private Text dateText;
  @FXML private Text descriptionText;
  @FXML private Text categoryText;
  @FXML private Text amountText;

  @FXML private Button receiptButton;
  @FXML private Button editButton;
  @FXML private Button deleteButton;
  @FXML
  public void initialize() {}

  /**
   * Method to init the FXML with correct values.
   *
   * @param accountingEntry the AccountingEntry
   */
  public void initData(AccountingEntry accountingEntry) {
    Category currentCategory = CategoriesController.getInstance().getCategoryById(accountingEntry.getCategoryId());
    if (currentCategory == null) {
      throw new IllegalArgumentException("Category does not exist");
    }
    dateText.setText(BaeconDateFormatter.format(accountingEntry.getDate()));
    descriptionText.setText(accountingEntry.getDescription());
    categoryText.setText(currentCategory.getName());
    amountText.setText(String.format("%s%.2f kr",accountingEntry.isExpense() ? "-" : "", accountingEntry.getAmount()));

    receiptButton.setOnAction(actionEvent -> {
      System.out.println("receipt for entry: " + accountingEntry.getId());
    });

    editButton.setOnAction(actionEvent -> {
      System.out.println("edit entry: " + accountingEntry.getId());
    });

    deleteButton.setOnAction(actionEvent -> {
      System.out.println("delete entry: " + accountingEntry.getId());
    });
  }
}
