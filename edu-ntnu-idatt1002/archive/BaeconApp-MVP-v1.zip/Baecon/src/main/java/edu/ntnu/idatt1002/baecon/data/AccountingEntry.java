package edu.ntnu.idatt1002.baecon.data;

import java.util.Date;
import java.util.UUID;

/**
 * The AccountEntry class, inheriting from the Entry class.
 * Handling the account entry's
 * by an id, an expense, a date, an amount and a category of the entry.
 */
public class AccountingEntry extends Entry {
  private String description;
  private UUID receiptId;

  private Date date;

  /**
   * Constructor of the Entry class.
   *
   * @param expense     true for expense and false for income (boolean)
   * @param date        the date of an entry (Date)
   * @param amount      the amount of an entry in norwegian kroner (double)
   * @param categoryId    the category of an entry (Category)
   * @param description the description of an account entry (String)
   * @param pdfId       the identity of a pdf receipt (UUID)
   */
  public AccountingEntry(boolean expense, Date date, double amount, UUID categoryId,
      String description, UUID pdfId) {
    super(expense, amount, categoryId);
    this.description = description;
    this.receiptId = pdfId;
    setDate(date);
  }

  /**
   * Alternative constructor of the Entry class, accepting id as a parameter.
   *
   * @param id       the id of the entry (UUID)
   * @param expense  true for expense and false for income (boolean)
   * @param date     the date of an entry (Date)
   * @param amount   the amount of an entry in norwegian kroner (double)
   * @param categoryId the category of an entry (Category)
   * @param description the description of an account entry (String)
   * @param pdfId       the identity of a pdf receipt (UUID)
   */
  public AccountingEntry(UUID id, boolean expense, Date date, double amount,
      UUID categoryId, String description, UUID pdfId) {
    super(id, expense, amount, categoryId);
    this.description = description;
    this.receiptId = pdfId;
    setDate(date);
  }

  /**
   * Accessing the description of an accounting entry.
   *
   * @return description (String)
   */
  public String getDescription() {
    return description;
  }

  /**
   * Changing the description of an accounting entry.
   * Checking if the new description is empty or not, and throwing an exception if it is.
   *
   * @param description (String)
   * @throws IllegalArgumentException "The description can not be empty."
   */
  public void setDescription(String description) {
    if (description == null) {
      throw new IllegalArgumentException("The description can not be empty.");
    }
    this.description = description;
  }

  /**
   * Accessing the receipt ID of an accounting entry.
   *
   * @return receiptId (UUID)
   */
  public UUID getReceiptId() {
    return receiptId;
  }

  /**
   * Changing the receipt ID of an accounting entry.
   * Checking if the new receipt ID is empty or not, and throwing an exception if it is.
   *
   * @param receiptId (UUID)
   * @throws IllegalArgumentException "The receipt ID can not be empty."
   */
  public void setReceiptId(UUID receiptId) {
    if (receiptId == null) {
      throw new IllegalArgumentException("The receipt ID can not be empty.");
    }
    this.receiptId = receiptId;
  }

  /**
   * Accessing the date of the entry.
   *
   * @return date (Date)
   */
  public Date getDate() {
    return date;
  }

  /**
   * Changing the date of the entry.
   * Not allowing an empty date.
   *
   * @param date (Date)
   * @throws IllegalArgumentException "The date can not be empty."
   */
  public void setDate(Date date) {
    if (date == null) {
      throw new IllegalArgumentException("The date can not be empty.");
    }
    this.date = date;
  }
}
