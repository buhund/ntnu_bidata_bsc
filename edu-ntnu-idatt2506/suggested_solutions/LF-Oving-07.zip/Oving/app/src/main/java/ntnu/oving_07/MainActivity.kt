package ntnu.oving_07

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import ntnu.oving_07.databinding.ActivityMainBinding
import ntnu.oving_07.managers.FileManager
import ntnu.oving_07.managers.MyPreferenceManager
import ntnu.oving_07.model.Movie
import ntnu.oving_07.service.Database
import java.util.*

class MainActivity : AppCompatActivity() {

	private lateinit var ui: ActivityMainBinding
	private lateinit var myPreferenceManager: MyPreferenceManager
	private lateinit var fileManager: FileManager
	private lateinit var db: Database

	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)

		myPreferenceManager = MyPreferenceManager(this)
		myPreferenceManager.updateNightMode()

		fileManager = FileManager(this)
		fileManager.delete("movies_local.txt")

		db = Database(this)
		db.clear()

		// Read from file we created in res/raw
		val movies: ArrayList<Movie> = fileManager.readMoviesFromRawFile(R.raw.movies)
		// Insert all the info from the movies in the local database
		db.insertMovies(movies)
		// write movies to local file
		fileManager.writeMoviesToLocalFile("movies_local.txt", movies)

		ui = ActivityMainBinding.inflate(layoutInflater)
		setContentView(ui.root)
	}

	override fun onResume() {
		super.onResume()
		val color = myPreferenceManager.getString(
				resources.getString(R.string.color),
				resources.getString(R.string.color_default_value)
		)
		setBackgroundColor(color)
	}

	private fun setBackgroundColor(color: String) {
		when (color) {
			"blue"  -> ui.result.setBackgroundColor(Color.argb(100, 184, 211, 255))
			"green" -> ui.result.setBackgroundColor(Color.argb(100, 204, 252, 207))
			"red"   -> ui.result.setBackgroundColor(Color.argb(100, 252, 207, 204))
			else    -> ui.result.setBackgroundColor(Color.TRANSPARENT)
		}
	}

	override fun onCreateOptionsMenu(menu: Menu): Boolean {
		menuInflater.inflate(R.menu.settings, menu)
		menu.add(0, 1, 0, "Alle Filmer")
		menu.add(0, 2, 0, "Alle Skuespillere")
		menu.add(0, 3, 0, "Alle Reggisører")
		menu.add(0, 4, 0, "Filmer av James Cameron")
		menu.add(0, 5, 0, "Filmer med Leonardo Dicaprio")
		menu.add(0, 6, 0, "Skuespillere i Avengers: Endgame")
		return super.onCreateOptionsMenu(menu)
	}

	override fun onOptionsItemSelected(item: MenuItem): Boolean {
		when (item.itemId) {
			R.id.settings -> startActivity(Intent("ntnu.oving_07.SettingsActivity"))
			1             -> showResults(db.allMovies)
			2             -> showResults(db.allActors)
			3             -> showResults(db.allDirectors)
			4             -> showResults(db.getMoviesByDirector("James Cameron"))
			5             -> showResults(db.getMoviesForActor("Leonardo Dicaprio"))
			6             -> showResults(db.getActorsForMovie("Avengers: Endgame"))
			else          -> return super.onOptionsItemSelected(item)
		}
		return true
	}

	private fun showResults(list: ArrayList<String>) {
		val result = StringBuffer("")
		for (string in list) result.append("$string\n")
		ui.result.text = result
	}
}
