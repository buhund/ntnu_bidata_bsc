package ntnu.oving_07.managers

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import ntnu.oving_07.model.Movie

open class DatabaseManager(context: Context) :
		SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

	companion object {

		const val DATABASE_NAME = "MovieDatabase"
		const val DATABASE_VERSION = 1

		const val ID = "_id"

		const val TABLE_MOVIE = "MOVIE"
		const val MOVIE_TITLE = "title"

		const val TABLE_DIRECTOR = "DIRECTOR"
		const val DIRECTOR_NAME = "name"

		const val TABLE_ACTOR = "ACTOR"
		const val ACTOR_NAME = "name"

		const val TABLE_MOVIE_DIRECTOR = "MOVIE_DIRECTOR"
		const val MOVIE_ID = "movie_id"
		const val DIRECTOR_ID = "director_id"

		const val TABLE_MOVIE_ACTOR = "MOVIE_ACTOR"
		const val ACTOR_ID = "actor_id"

		val JOIN_MOVIES_ACTORS = arrayOf(
				"$TABLE_MOVIE.$ID=$TABLE_MOVIE_ACTOR.$MOVIE_ID",
				"$TABLE_ACTOR.$ID=$TABLE_MOVIE_ACTOR.$ACTOR_ID"
		)
		val JOIN_MOVIES_DIRECTORS = arrayOf(
				"$TABLE_MOVIE.$ID=$TABLE_MOVIE_DIRECTOR.$MOVIE_ID",
				"$TABLE_DIRECTOR.$ID=$TABLE_MOVIE_DIRECTOR.$DIRECTOR_ID",
		)
	}

	override fun onCreate(db: SQLiteDatabase) {
		db.execSQL(
				"""create table $TABLE_MOVIE (
						$ID integer primary key autoincrement, 
						$MOVIE_TITLE text not null
						);"""
		)
		db.execSQL(
				"""create table $TABLE_ACTOR (
						$ID integer primary key autoincrement, 
						$ACTOR_NAME text unique not null
						);"""
		)
		db.execSQL(
				"""create table $TABLE_DIRECTOR (
						$ID integer primary key autoincrement, 
						$DIRECTOR_NAME text unique not null
						);"""
		)
		db.execSQL(
				"""create table $TABLE_MOVIE_DIRECTOR (
						$ID integer primary key autoincrement, 
						$MOVIE_ID numeric,
						$DIRECTOR_ID numeric, 
						FOREIGN KEY($MOVIE_ID) REFERENCES $TABLE_MOVIE($ID), 
						FOREIGN KEY($DIRECTOR_ID) REFERENCES $TABLE_DIRECTOR($ID)
						);"""
		)
		db.execSQL(
				"""create table $TABLE_MOVIE_ACTOR (
						$ID integer primary key autoincrement, 
						$MOVIE_ID numeric,
						$ACTOR_ID numeric, 
						FOREIGN KEY($MOVIE_ID) REFERENCES $TABLE_MOVIE($ID), 
						FOREIGN KEY($ACTOR_ID) REFERENCES $TABLE_ACTOR($ID)
						);"""
		)
	}

	override fun onUpgrade(db: SQLiteDatabase, arg1: Int, arg2: Int) {
		db.execSQL("DROP TABLE IF EXISTS $TABLE_MOVIE_DIRECTOR")
		db.execSQL("DROP TABLE IF EXISTS $TABLE_MOVIE_ACTOR")
		db.execSQL("DROP TABLE IF EXISTS $TABLE_ACTOR")
		db.execSQL("DROP TABLE IF EXISTS $TABLE_DIRECTOR")
		db.execSQL("DROP TABLE IF EXISTS $TABLE_MOVIE")
		onCreate(db)
	}

	fun clear() {
		writableDatabase.use { onUpgrade(it, 0, 0) }
	}

	fun insert(movie: Movie) {

		writableDatabase.use { database ->
			val movieId = insertValueIfNotExists(database, TABLE_MOVIE, MOVIE_TITLE, movie.title)
			val directorId = insertValueIfNotExists(
					database, TABLE_DIRECTOR, DIRECTOR_NAME, movie.director
			)
			val actorIds = ArrayList<Long>()
			for (actor in movie.actors) {
				actorIds.add(insertValueIfNotExists(database, TABLE_ACTOR, ACTOR_NAME, actor))
			}
			linkMovieDirectorActors(database, movieId, directorId)
			linkMovieAndActors(database, movieId, actorIds)
		}
	}

	private fun insertValueIfNotExists(
		database: SQLiteDatabase, table: String, field: String, value: String
	): Long {
		// Query for the value
		query(database, table, arrayOf(ID, field), "$field='$value'").use { cursor ->
			// insert if value doesn't exist
			return if (cursor.count != 0) {
				cursor.moveToFirst()
				cursor.getLong(0) //id of found value
			} else {
				insertValue(database, table, field, value)
			}
		}
	}

	private fun insertValue(
		database: SQLiteDatabase, table: String, field: String, value: String
	): Long {
		val values = ContentValues()
		values.put(field, value.trim())
		return database.insert(table, null, values)
	}

	private fun linkMovieDirectorActors(
		database: SQLiteDatabase, movieId: Long, directorId: Long
	) {
		val values = ContentValues()
		values.put(MOVIE_ID, movieId)
		values.put(DIRECTOR_ID, directorId)
		database.insert(TABLE_MOVIE_DIRECTOR, null, values)
	}

	private fun linkMovieAndActors(
		database: SQLiteDatabase, movieId: Long, actorIds: ArrayList<Long>
	) {
		for (actorId in actorIds) {
			val values = ContentValues()
			values.put(MOVIE_ID, movieId)
			values.put(ACTOR_ID, actorId)
			database.insert(TABLE_MOVIE_ACTOR, null, values)
		}
	}


	fun performQuery(
		table: String, columns: Array<String>, selection: String?
	): ArrayList<String> {
		assert(columns.isNotEmpty())
		readableDatabase.use { database ->
			query(database, table, columns, selection).use { cursor ->
				return readFromCursor(cursor, columns.size)
			}
		}
	}

	fun performRawQuery(
		select: Array<String>, from: Array<String>, join: Array<String>, where: String? = null
	): ArrayList<String> {

		val query = StringBuilder("SELECT ")
		for ((i, field) in select.withIndex()) {
			query.append(field)
			if (i != select.lastIndex) query.append(", ")
		}

		query.append(" FROM ")
		for ((i, table) in from.withIndex()) {
			query.append(table)
			if (i != from.lastIndex) query.append(", ")
		}

		query.append(" WHERE ")
		for ((i, link) in join.withIndex()) {
			query.append(link)
			if (i != join.lastIndex) query.append(" and ")
		}

		if (where != null) query.append(" and $where")

		readableDatabase.use { db ->
			db.rawQuery("$query;", null).use { cursor ->
				return readFromCursor(cursor, select.size)
			}
		}
	}

	private fun readFromCursor(cursor: Cursor, numberOfColumns: Int): ArrayList<String> {
		val result = ArrayList<String>()
		cursor.moveToFirst()
		while (!cursor.isAfterLast) {
			val item = StringBuilder("")
			for (i in 0 until numberOfColumns) {
				item.append("${cursor.getString(i)} ")
			}
			result.add("$item")
			cursor.moveToNext()
		}
		return result
	}

	private fun query(
		database: SQLiteDatabase, table: String, columns: Array<String>, selection: String?
	): Cursor {
		return database.query(table, columns, selection, null, null, null, null, null)
	}
}
