package ntnu.oving_07.managers

import androidx.appcompat.app.AppCompatActivity
import ntnu.oving_07.model.Movie
import java.io.*

class FileManager(private val activity: AppCompatActivity) {

	private val localDir: File = activity.filesDir

	fun readMoviesFromRawFile(fileId: Int): ArrayList<Movie> {
		val content = ArrayList<Movie>()
		try {
			val inputStream: InputStream = activity.resources.openRawResource(fileId)
			BufferedReader(InputStreamReader(inputStream)).use { reader ->
				var line = reader.readLine()
				while (line != null) {
					content.add(Movie.from(line))
					line = reader.readLine()
				}
			}
		} catch (e: IOException) {
			e.printStackTrace()
		}
		return content
	}

	fun writeMoviesToLocalFile(filename: String, movies: ArrayList<Movie>) {
		val file = File(localDir, filename)
		PrintWriter(file).use { writer ->
			for (movie in movies) {
				writer.println(movie.toString())
			}
		}
	}

	fun delete(filename: String) {
		val file = File(localDir, filename)
		file.delete()
	}
}
