package ntnu.oving_07.service

import android.content.Context
import ntnu.oving_07.managers.DatabaseManager
import ntnu.oving_07.model.Movie

class Database(context: Context) : DatabaseManager(context) {

	fun insertMovies(movies: ArrayList<Movie>) {
		for (movie in movies) insert(movie)
	}

	val allMovies: ArrayList<String>
		get() = performQuery(TABLE_MOVIE, arrayOf(MOVIE_TITLE), null)

	val allDirectors: ArrayList<String>
		get() = performQuery(TABLE_DIRECTOR, arrayOf(DIRECTOR_NAME), null)

	val allActors: ArrayList<String>
		get() = performQuery(TABLE_ACTOR, arrayOf(ACTOR_NAME), null)

	fun getMoviesByDirector(director: String): ArrayList<String> {
		val select = arrayOf("$TABLE_MOVIE.$MOVIE_TITLE")
		val from = arrayOf(TABLE_MOVIE, TABLE_DIRECTOR, TABLE_MOVIE_DIRECTOR)
		val join = JOIN_MOVIES_DIRECTORS
		val where = "$TABLE_DIRECTOR.$DIRECTOR_NAME='$director'"
		return performRawQuery(select, from, join, where)
	}

	fun getActorsForMovie(movie: String): ArrayList<String> {
		val select = arrayOf("$TABLE_ACTOR.$ACTOR_NAME")
		val from = arrayOf(TABLE_MOVIE, TABLE_ACTOR, TABLE_MOVIE_ACTOR)
		val join = JOIN_MOVIES_ACTORS
		val where = "$TABLE_MOVIE.$MOVIE_TITLE='$movie'"
		return performRawQuery(select, from, join, where)
	}

	fun getMoviesForActor(actor: String): ArrayList<String> {
		val select = arrayOf("$TABLE_MOVIE.$MOVIE_TITLE")
		val from = arrayOf(TABLE_MOVIE, TABLE_ACTOR, TABLE_MOVIE_ACTOR)
		val join = JOIN_MOVIES_ACTORS
		val where = "$TABLE_ACTOR.$ACTOR_NAME='$actor'"
		return performRawQuery(select, from, join, where)
	}
}
