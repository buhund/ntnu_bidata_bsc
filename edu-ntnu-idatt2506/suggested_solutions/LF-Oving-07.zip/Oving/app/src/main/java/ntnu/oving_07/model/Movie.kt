package ntnu.oving_07.model

data class Movie(
	val title: String, val director: String, val actors: List<String>
) {

	override fun toString(): String {
		var actorsStr = ""
		for ((i, actor) in actors.withIndex()) {
			actorsStr += actor
			if (i != actors.lastIndex) actorsStr += ACTOR_SEPARATOR
		}
		return "$title$VALUE_SEPARATOR$director$VALUE_SEPARATOR$actorsStr"
	}

	companion object {

		const val VALUE_SEPARATOR = "#"
		const val ACTOR_SEPARATOR = "&"

		fun from(string: String): Movie {
			val values = string.split(VALUE_SEPARATOR)
			val title = values[0]
			val director = values[1]
			val actors = values[2].split(ACTOR_SEPARATOR)
			return Movie(title, director, actors)
		}
	}
}
