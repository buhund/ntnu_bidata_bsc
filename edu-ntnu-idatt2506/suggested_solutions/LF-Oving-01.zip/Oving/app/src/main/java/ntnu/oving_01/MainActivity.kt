package ntnu.oving_01

import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    override fun onCreateOptionsMenu(meny: Menu): Boolean {
        super.onCreateOptionsMenu(meny)
        meny.add("Ola")
        meny.add("Nordmann")
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.title!!.equals("Ola")) {
            Log.w(getString(R.string.TAG), "Trykket på \"Ola\"")
        }
        if (item.title!!.equals("Nordmann")) {
            Log.e(getString(R.string.TAG), "Trykket på \"Nordmann\"")
        }
        return true
    }
}