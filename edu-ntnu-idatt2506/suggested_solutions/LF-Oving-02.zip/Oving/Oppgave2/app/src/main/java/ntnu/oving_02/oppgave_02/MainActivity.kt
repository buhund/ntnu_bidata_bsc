package ntnu.oving_02.oppgave_02

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

	enum class Calculation { ADDITION, MULTIPLICATION }


	private lateinit var number1TextView: TextView
	private lateinit var number2TextView: TextView
	private lateinit var answerEditText: EditText
	private lateinit var boundaryEditText: EditText


	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		setContentView(R.layout.activity_main)

		number1TextView = findViewById(R.id.number1)
		number2TextView = findViewById(R.id.number2)
		answerEditText = findViewById(R.id.answer)
		boundaryEditText = findViewById(R.id.edit_number_boundary)
	}

	private fun checkCalculation(type: Calculation) {
		try {

			val number1 = number1TextView.text.toString().toInt()
			val number2 = number2TextView.text.toString().toInt()
			val answer = answerEditText.text.toString().toInt()
			val numberBoundary = boundaryEditText.text.toString().toInt()

			// Calculate correct answer
			val correctAnswer = when (type) {
				Calculation.ADDITION -> number1 + number2
				Calculation.MULTIPLICATION -> number1 * number2
			}

			// Show Toast with result
			giveAnswerResponse(answer, correctAnswer)

			// Update numbers
			getNewNumbers(numberBoundary)
		} catch (e: Exception) {
			Toast.makeText(this, "Error: invalid input", Toast.LENGTH_SHORT).show()
		}
	}

	fun onAdditionClicked(view: View?) {
		checkCalculation(Calculation.ADDITION)
	}

	fun onMultiplicationClicked(view: View?) {
		checkCalculation(Calculation.MULTIPLICATION)
	}

	private fun giveAnswerResponse(answer: Int, correctAnswer: Int) {
		var message = getString(R.string.correct)
		if (answer != correctAnswer) {
			message = "${getString(R.string.incorrect)} $correctAnswer"
		}
		Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
	}

	private fun getNewNumbers(numberBoundary: Int) {
		// Ask RandomActivity for new random numbers (they are changed in onActivityResult)
		val intent = Intent("RandomActivity").putExtra("number-boundary", numberBoundary)
		startActivityForResult(intent, 1)
		startActivityForResult(intent, 2)
	}

	override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
		super.onActivityResult(requestCode, resultCode, data)
		if (resultCode != RESULT_OK) return
		val randomNumber = data!!.getIntExtra("random-number", -1).toString()
		when (requestCode) {
			1 -> number1TextView.text = randomNumber
			2 -> number2TextView.text = randomNumber
		}
	}
}
