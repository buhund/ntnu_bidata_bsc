package ntnu.oving_02.oppgave_02

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class RandomActivity : AppCompatActivity() {

	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		setContentView(R.layout.activity_random)

		val numberBoundary = intent.getIntExtra("number-boundary", -1)
		val randomNumber = (0..numberBoundary).random()

		setResult(RESULT_OK, Intent().putExtra("random-number", randomNumber))
		finish()
	}
}
