package ntnu.oving_02.oppgave_01

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class RandomActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_random)

        var randomNumber = (0..100).random()
        Toast.makeText(this, "Toast with random number:  $randomNumber", Toast.LENGTH_SHORT).show()

        val numberBoundary = intent.getIntExtra("number-boundary", 100)
        randomNumber = (0..numberBoundary).random()

        setResult(RESULT_OK, Intent().putExtra("random_number", randomNumber))
        finish()
    }
}
