package ntnu.oving_02.oppgave_01

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

	private val REQUEST_CODE = 1

	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		setContentView(R.layout.activity_main)

		val numberBoundary = 500
		val intent = Intent("RandomActivity")
		intent.putExtra("number-boundary", numberBoundary)

		startActivityForResult(intent, REQUEST_CODE)

		findViewById<TextView>(R.id.number_boundary_text).text = "Number boundary: $numberBoundary"
	}

	override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
		super.onActivityResult(requestCode, resultCode, data)
		if (resultCode != RESULT_OK) return
		when (requestCode) {
			REQUEST_CODE -> {
				val textView = findViewById<TextView>(R.id.default_textView)
				val text =
					"Random number from other activity: " + data!!.getIntExtra("random_number", -1)
				textView.text = text
			}
		}
	}
}
