package ntnu.leksjon_06.klient

import android.app.Activity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch

class MainActivity : Activity() {

	private val client = Client(this)

	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		setContentView(R.layout.activity_main)
	}

	/**
	 * Send whatever is currently in the message field to the server
	 */
	fun onClickSend(v: View?) {
		val messageInput: EditText = findViewById(R.id.input)
		val message: String = messageInput.text.toString().trim()
		if (message != "") {
			client.sendToServer(message)
			messageInput.text.clear()
			addOutgoingMessage(message)
		}
	}

	/**
	 * Add a new message to the outgoing messages
	 */
	private fun addOutgoingMessage(newMessage: String) {
		addMessage(findViewById(R.id.outgoing), newMessage)
	}

	/**
	 * Add a new massage in the "inbox", done in main scope so it can be called from the server
	 * class
	 */
	fun addIncomingMessage(newMessage: String) {
		MainScope().launch {
			addMessage(findViewById(R.id.incoming), newMessage)
		}
	}


	/**
	 * Add new message under the previous ones for a textview
	 */
	private fun addMessage(textView: TextView, newMessage: String) {
		val oldMessages = textView.text.toString()
		val newStr = "$oldMessages\n$newMessage"
		textView.text = newStr
	}

	/**
	 * Change the info on the screen to the message given
	 */
	fun setInfo(message: String) {
		MainScope().launch {
			findViewById<TextView>(R.id.info).text = message
		}
	}

	/**
	 * Stop the server when activity is destroyed
	 */
	override fun onDestroy() {
		super.onDestroy()
		client.closeConnectionToServer()
	}
}
