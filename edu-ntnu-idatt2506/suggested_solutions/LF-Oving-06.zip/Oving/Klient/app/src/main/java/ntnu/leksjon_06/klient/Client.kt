package ntnu.leksjon_06.klient

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers.IO
import kotlinx.coroutines.launch
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.Socket

class Client(
	private val mainActivity: MainActivity,
	private val PORT: Int = 12345,
	private val IP: String = "10.0.2.2"
) {

	private lateinit var server: Socket
	private lateinit var serverReader: BufferedReader
	private lateinit var serverWriter: PrintWriter

	private val isConnected: Boolean get() = !server.isClosed

	init {
		mainActivity.setInfo("Kobler til tjeneren")
		CoroutineScope(IO).launch {
			try {
				server = Socket(IP, PORT)

				mainActivity.setInfo("Tilkoblet Tjener")

				serverReader = BufferedReader(InputStreamReader(server.getInputStream()))
				serverWriter = PrintWriter(server.getOutputStream(), true)

				startReadingFromServer()
			} catch (e: IOException) {
				e.printStackTrace()
				e.message?.let { mainActivity.setInfo(it) }
			}
		}
	}


	/**
	 * Listen to the server and update the message in main activity whenever one is received
	 */
	private fun startReadingFromServer() {
		CoroutineScope(IO).launch {
			try {
				while (isConnected) {
					val message = serverReader.readLine()
					if (message != null) {
						mainActivity.addIncomingMessage(message)
					}
				}
			}catch(e: IOException){
				mainActivity.setInfo("Tjeneren skudde seg av")
				closeConnectionToServer()
			}
		}
	}

	/**
	 * Send the message to the server
	 */
	fun sendToServer(message: String) {
		CoroutineScope(IO).launch {
			serverWriter.println(message)
		}
	}

	/**
	 * Close the socket that is connected to the server
	 */
	fun closeConnectionToServer() {
		try {
			server.close()
		} catch (e: IOException) {
			e.printStackTrace()
		}
	}
}
