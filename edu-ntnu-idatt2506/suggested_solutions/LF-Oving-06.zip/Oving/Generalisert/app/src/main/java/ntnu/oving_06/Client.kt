package ntnu.oving_06

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.IOException
import java.net.Socket

class Client(
	private val activity: MainActivity,
	private val PORT: Int = 12345,
	private val IP: String = "10.0.2.2"
) {

	private lateinit var server: SocketConnection
	var connected: Boolean = false

	init {
		CoroutineScope(Dispatchers.IO).launch {
			try {
				server = SocketConnection(Socket(IP, PORT))
				server.onMessage { message: String ->
					activity.addIncomingMessage(message)
				}
				connected = true

				activity.setInfo("Jeg er en klient!")
			} catch (e: IOException) {
				connected = false
			}
		}
	}

	fun send(message: String) = server.send(message)

	fun close() = server.close()
}
