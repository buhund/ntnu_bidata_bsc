package ntnu.oving_06

import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

	private lateinit var asClient: Client
	private lateinit var asServer: Server

	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		setContentView(R.layout.activity_main)

		asClient = Client(this)
		if (!asClient.connected) asServer = Server(this)
	}

	fun onClickSend(v: View?) {
		val input = findViewById<EditText>(R.id.input)
		val message: String = input.text.toString()
		if (message.trim() != "") {
			if (asClient.connected) {
				asClient.send(message)
			} else {
				asServer.send(message)
			}
			input.text.clear()
		}
		addOutgoingMessage(message)
	}

	/**
	 * Add new message under the previous outgoing messages
	 */
	fun addIncomingMessage(message: String) {
		addMessage(findViewById(R.id.incoming), message)
	}

	/**
	 * Add new message under the previous incoming messages
	 */
	private fun addOutgoingMessage(message: String) {
		addMessage(findViewById(R.id.outgoing), message)
	}

	/**
	 * Add new message under the previous ones for a view
	 */
	private fun addMessage(textView: TextView, message: String) {
		MainScope().launch {
			val newText = "${textView.text}\n$message"
			textView.text = newText
		}
	}

	/**
	 * Set text that appears on top of the screen
	 */
	fun setInfo(message: String?) {
		val info: TextView = findViewById(R.id.info)
		MainScope().launch { info.text = message }
	}

	/**
	 * Close chat sockets when activity is destroyed
	 */
	override fun onDestroy() {
		super.onDestroy()
		if (asClient.connected) {
			asClient.close()
		} else {
			asServer.close()
		}
	}
}
