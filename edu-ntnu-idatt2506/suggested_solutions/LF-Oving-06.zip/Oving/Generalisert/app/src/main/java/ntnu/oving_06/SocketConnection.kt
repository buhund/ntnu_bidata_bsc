package ntnu.oving_06

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.Socket

/**
 * This class handles everything related to sending, reading and closing a socket.
 */
class SocketConnection(val socket: Socket) {

	private var reader: BufferedReader = BufferedReader(InputStreamReader(socket.getInputStream()))
	private var writer: PrintWriter = PrintWriter(socket.getOutputStream(), true)

	/**
	 *  Continuously read from the inputStream
	 *
	 *  When a message is received we use the callback function
	 *
	 *  ```
	 *  <SocketConnection>.onMessage { message: String ->
	 *      println(message)
	 *  }
	 *  ```
	 */
	fun onMessage(callback: (message: String) -> Unit) {
		CoroutineScope(Dispatchers.IO).launch {
			try {
				while (true) {
					val message = reader.readLine()
					if (message != null) {
						callback(message)
					}
				}
			} catch (e: IOException) {
				close()
				callback("***Disconnected***")
			}
		}
	}

	/**
	 *  Send a single message to this socket
	 */
	fun send(message: String) {
		CoroutineScope(Dispatchers.IO).launch {
			writer.println(message)
		}
	}

	/**
	 *  Close the socket
	 */
	fun close() {
		try {
			socket.close()
		} catch (e: IOException) {
			e.printStackTrace()
		}
	}
}
