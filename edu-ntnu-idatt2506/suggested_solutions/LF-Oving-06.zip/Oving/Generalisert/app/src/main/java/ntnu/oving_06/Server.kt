package ntnu.oving_06

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.net.ServerSocket
import java.net.Socket


/**
 *
 * Remember to run the following command (using the emulator you are launching the server on, and
 * the correct port number).
 *
 *  ```
 *  adb -s emulator-5554 forward tcp:12345 tcp:12345
 *  ```
 */
class Server(
	private val activity: MainActivity, private val PORT: Int = 12345
) {

	private val clients = mutableListOf<SocketConnection>()

	init {
		CoroutineScope(Dispatchers.IO).launch {
			ServerSocket(PORT).use { serverSocket: ServerSocket ->

				activity.setInfo("Jeg er tjeneren!")

				// Keep checking for new clients
				while (true) {
					val client: Socket = serverSocket.accept()
					handleClient(client)
				}
			}
		}
	}

	/**
	 * Start new coroutine for this specific client
	 */
	private fun handleClient(socket: Socket) {
		val client = SocketConnection(socket)
		client.onMessage { message: String ->
			activity.addIncomingMessage(message)
			sendToAllExcept(message, socket)
		}
		clients.add(client)
	}

	/**
	 * Send to all clients except the one with the given socket
	 */
	private fun sendToAllExcept(message: String, sender: Socket) {
		for (client in clients) if (client.socket != sender) client.send(message)
	}

	/**
	 * Send the message to all connected clients
	 */
	fun send(message: String) {
		for (client in clients) client.send(message)
	}

	/**
	 * Close all sockets
	 */
	fun close() {
		for (client in clients) {
			client.close()
		}
	}
}
