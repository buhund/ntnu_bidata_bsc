package ntnu.leksjon_06.tjener

import android.app.Activity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch

class MainActivity : Activity() {

	private val server = Server(this)

	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		setContentView(R.layout.activity_main)
		server.start()
	}

	/**
	 * Make sure a client is connected and send them whatever is currently in the message field
	 */
	fun onClickSend(v: View?) {
		if (!server.isConnectedToClient) {
			Toast.makeText(
					this, "Ingen klient tilkoblet", Toast.LENGTH_LONG
			).show()
			return
		}
		val messageInput: EditText = findViewById(R.id.input)
		val message: String = messageInput.text.toString().trim()
		if (message != "") {
			server.sendToClient(message)
			messageInput.text.clear()
			addOutgoingMessage(message)
		}
	}

	/**
	 * Add a new message to the outgoing messages
	 */
	private fun addOutgoingMessage(newMessage: String) {
		addMessage(findViewById(R.id.outgoing), newMessage)
	}

	/**
	 * Add a new massage in the "inbox", done in main scope so it can be called from the server
	 * class
	 */
	fun addIncomingMessage(newMessage: String) {
		MainScope().launch {
			addMessage(findViewById(R.id.incoming), newMessage)
		}
	}


	/**
	 * Add new message under the previous ones for a textview
	 */
	private fun addMessage(textView: TextView, newMessage: String) {
		val oldMessages = textView.text.toString()
		val newStr = "$oldMessages\n$newMessage"
		textView.text = newStr
	}

	/**
	 * Change the info on the screen to the message given
	 */
	fun setInfo(message: String) {
		MainScope().launch {
			findViewById<TextView>(R.id.info).text = message
		}
	}

	/**
	 * Stop the server when activity is destroyed
	 */
	override fun onDestroy() {
		super.onDestroy()
		server.stop()
	}
}
