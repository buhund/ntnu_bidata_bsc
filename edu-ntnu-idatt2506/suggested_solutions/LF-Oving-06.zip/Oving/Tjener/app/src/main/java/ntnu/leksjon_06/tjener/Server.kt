package ntnu.leksjon_06.tjener

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers.IO
import kotlinx.coroutines.launch
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.ServerSocket
import java.net.Socket

/**
 *
 * Remember to run the following command (using the emulator you are launching the server on, and
 * the correct port number).
 *
 *  ```
 *  adb -s emulator-5554 forward tcp:12345 tcp:12345
 *  ```
 */
class Server(private val mainActivity: MainActivity, private val PORT: Int = 12345) {

	private var clientSocket: Socket? = null
	private var clientWriter: PrintWriter? = null
	private var clientReader: BufferedReader? = null

	val isConnectedToClient: Boolean
		get() = clientWriter != null

	/**
	 * Create the server-socket and wait for a client to connect
	 */
	fun start() {
		mainActivity.setInfo("Starter Tjener ...")

		CoroutineScope(IO).launch {

			try {
				val serverSocket = ServerSocket(PORT)
				mainActivity.setInfo("ServerSocket opprettet, venter på en klient")

				val clientSocket = serverSocket.accept()
				mainActivity.setInfo("En Klient er tilkoblet")

				clientReader = BufferedReader(InputStreamReader(clientSocket.getInputStream()))
				clientWriter = PrintWriter(clientSocket.getOutputStream(), true)

				startReadingFromClient()
			} catch (e: IOException) {
				e.printStackTrace()
				e.message?.let { mainActivity.setInfo(it) }
			}
		}
	}

	/**
	 * Listen to the client socket and update the message in main activity whenever one is received
	 */
	private fun startReadingFromClient() {
		CoroutineScope(IO).launch {
			try {
				while (true) {
					val message = clientReader?.readLine()
					if (message != null) {
						mainActivity.addIncomingMessage(message)
					}
				}
			} catch (e: IOException) {
				clientWriter = null
				clientReader = null
				mainActivity.setInfo("Klienten koblet fra")
			}
		}
	}

	/**
	 * Send the message to the client
	 */
	fun sendToClient(message: String) {
		CoroutineScope(IO).launch {
			clientWriter?.println(message)
		}
	}

	/**
	 * Close all the sockets
	 */
	fun stop() {
		try {
			clientSocket?.close()
		} catch (e: IOException) {
			e.printStackTrace()
		}
	}
}
