package ntnu.oving_04.fragments

import android.app.Activity
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.fragment.app.ListFragment
import ntnu.oving_04.R

class SelectionFragment : ListFragment() {

    private lateinit var movieTitles: Array<String>
    private lateinit var movieDescriptions: Array<String>
    private lateinit var movieListener: SelectionListener


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val resources = resources
        movieTitles = resources.getStringArray(R.array.move_titles)
        movieDescriptions = resources.getStringArray(R.array.movie_descriptions)
        listAdapter = activity?.let {
            ArrayAdapter(
                it, android.R.layout.simple_list_item_1, android.R.id.text1, movieTitles
            )
        }
    }

    override fun onAttach(activity: Activity) {
        super.onAttach(activity)
        movieListener = try {
            activity as SelectionListener
        } catch (cce: ClassCastException) {
            throw ClassCastException("$activity must implement SelectionListener")
        }
    }

    override fun onListItemClick(l: ListView, v: View, position: Int, id: Long) {
        super.onListItemClick(l, v, position, id)
        movieListener.onSelectionListener(
            position, movieTitles[position], movieDescriptions[position]
        )
    }

    interface SelectionListener {

        fun onSelectionListener(resourceId: Int, title: String?, movieDescription: String?)
    }
}
