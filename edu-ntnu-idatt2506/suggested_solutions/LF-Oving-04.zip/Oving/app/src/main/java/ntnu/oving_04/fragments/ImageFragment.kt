package ntnu.oving_04.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment
import ntnu.oving_04.R

class ImageFragment : Fragment() {

    private lateinit var title: TextView
    private lateinit var description: TextView
    private lateinit var image: ImageView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_image, container, false)
        title = view.findViewById(R.id.fragment_image_movie_title)
        description = view.findViewById(R.id.fragment_image_description)
        image = view.findViewById(R.id.fragment_image_view)
        return view
    }

    fun changeImage(resourceId: Int, movieTitle: String?, movieDescription: String?) {
        title.text = movieTitle
        image.setImageResource(resourceId)
        description.text = movieDescription
    }
}
