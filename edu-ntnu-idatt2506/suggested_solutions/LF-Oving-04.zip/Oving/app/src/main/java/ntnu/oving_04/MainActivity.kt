package ntnu.oving_04


import android.content.res.Configuration
import android.content.res.TypedArray
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.children
import ntnu.oving_04.fragments.ImageFragment
import ntnu.oving_04.fragments.SelectionFragment


class MainActivity : AppCompatActivity(), SelectionFragment.SelectionListener {

    private var selected = 0

    private lateinit var movieCovers: TypedArray
    private lateinit var movieTitles: Array<String>
    private lateinit var movieDescriptions: Array<String>

    private lateinit var imageFragment: ImageFragment
    private lateinit var selectionFragment: SelectionFragment

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val resources = resources
        movieCovers = resources.obtainTypedArray(R.array.movie_covers)
        movieTitles = resources.getStringArray(R.array.move_titles)
        movieDescriptions = resources.getStringArray(R.array.movie_descriptions)

        imageFragment =
            supportFragmentManager.findFragmentById(R.id.image_fragment) as ImageFragment
        selectionFragment =
            supportFragmentManager.findFragmentById(R.id.selector_fragment) as SelectionFragment
    }

    override fun onStart() {
        super.onStart()
        selectMovie(selected)
        onConfigurationChanged(resources.configuration)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.menu_previous -> previousImage()
            R.id.menu_next -> nextImage()
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val isPortrait: Boolean = newConfig.orientation == Configuration.ORIENTATION_PORTRAIT
        val layout = findViewById<LinearLayout>(R.id.fragment_layout)
        if (isPortrait) {
            layout.orientation = LinearLayout.VERTICAL
            for (view in layout.children) {
                view.layoutParams.height = 0
                view.layoutParams.width = MATCH_PARENT
            }
        } else {
            layout.orientation = LinearLayout.HORIZONTAL
            for (view in layout.children) {
                view.layoutParams.height = MATCH_PARENT
                view.layoutParams.width = 0
            }
        }
    }

    private fun previousImage() {
        if (selected == 0) return
        selected--
        selectMovie(selected)
    }

    private fun nextImage() {
        if (selected == movieTitles.lastIndex) return
        selected++
        selectMovie(selected)
    }

    private fun selectMovie(index: Int) {
        onSelectionListener(index, movieTitles[index], movieDescriptions[index])
    }

    override fun onSelectionListener(resourceId: Int, title: String?, movieDescription: String?) {
        selected = resourceId
        val resourceID = movieCovers.peekValue(resourceId).resourceId
        imageFragment.changeImage(resourceID, title, movieDescription)
    }
}
