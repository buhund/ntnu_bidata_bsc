package ntnu.oving_05

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.ViewSwitcher
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch

const val URL = "https://bigdata.idi.ntnu.no/mobil/tallspill.jsp"

class MainActivity : AppCompatActivity() {

    var http = HttpWrapper(URL)
    private var numGuesses = 0

    private lateinit var switcher: ViewSwitcher
    private lateinit var header: TextView
    private lateinit var fromServer: TextView
    private lateinit var submitButton: Button
    private lateinit var playButton: Button
    private lateinit var restartButton: Button
    private lateinit var nameInput: EditText
    private lateinit var cardInput: EditText
    private lateinit var numberInput: EditText


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        switcher = findViewById(R.id.switcher)
        header = findViewById(R.id.header)
        fromServer = findViewById(R.id.textFromServer)

        nameInput = findViewById(R.id.nameInput)
        cardInput = findViewById(R.id.cardInput)
        numberInput = findViewById(R.id.gameInput)

        submitButton = findViewById(R.id.submitButton)
        playButton = findViewById(R.id.playButton)
        restartButton = findViewById(R.id.restartButton)

        submitButton.setOnClickListener { onClickSubmit() }
        playButton.setOnClickListener { onClickPlay() }
        restartButton.setOnClickListener { onClickRestart() }
    }


    private fun onClickSubmit() {
        val name = nameInput.text.toString()
        val card = cardInput.text.toString()
        val data = mapOf(
            "navn" to name,
            "kortnummer" to card
        )
        CoroutineScope(Dispatchers.IO).launch {
            val response = http.get(data)
            MainScope().launch {
                fromServer.text = response
            }
        }
        header.setText(R.string.instruction)
        switcher.showNext()
    }

    private fun onClickPlay() {
        numGuesses++
        if (numGuesses == 3) {
            playButton.visibility = View.GONE
            restartButton.visibility = View.VISIBLE
        }
        val number = numberInput.text.toString()
        val data = mapOf("tall" to number)

        CoroutineScope(Dispatchers.IO).launch {
            val response = http.get(data)
            if (response.contains("vunnet")) {
                MainScope().launch {
                    playButton.visibility = View.GONE
                    restartButton.visibility = View.VISIBLE
                }
            }
            MainScope().launch {
                fromServer.text = response
            }
        }
    }

    private fun onClickRestart() {
        nameInput.setText("", TextView.BufferType.EDITABLE)
        cardInput.setText("", TextView.BufferType.EDITABLE)
        numberInput.setText("", TextView.BufferType.EDITABLE)
        recreate()
    }
}