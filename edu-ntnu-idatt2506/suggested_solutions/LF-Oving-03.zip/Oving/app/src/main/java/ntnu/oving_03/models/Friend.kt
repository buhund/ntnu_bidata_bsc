package ntnu.oving_03.models

class Friend(var name: String, var birthday: String) {

	override fun toString(): String {
		return name
	}
}
