package ntnu.oving_03

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import ntnu.oving_03.models.Friend
import java.util.*

class MainActivity : AppCompatActivity() {

	private lateinit var friendNameView: TextView
	private lateinit var friendBirthdayView: TextView
	private lateinit var friendNameEdit: EditText
	private lateinit var friendBirthdayEdit: EditText
	private lateinit var editLayout: GridLayout
	private lateinit var editButtonLayout: LinearLayout
	private lateinit var editFriendButton: Button
	private lateinit var addFriendButton: Button

	private lateinit var spinner: Spinner

	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		setContentView(R.layout.activity_main)
		friends.add(Friend("Kari Nordmann", "16. apr 1999"))
		friends.add(Friend("Ola Nordmann", "25. des 1997"))

		friendNameView = findViewById(R.id.friendName)
		friendBirthdayView = findViewById(R.id.friendBirthday)
		friendNameEdit = findViewById(R.id.edit_friendName)
		friendBirthdayEdit = findViewById(R.id.edit_friendBirthday)

		editLayout = findViewById(R.id.layout_editFriend)
		editButtonLayout = findViewById(R.id.editFriendButtons)
		editFriendButton = findViewById(R.id.button_editFriend)
		addFriendButton = findViewById(R.id.button_addFriend)

		spinner = findViewById(R.id.spinner)
		initSpinner()
	}

	private fun initSpinner() {
		spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, friends)
		spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
			override fun onItemSelected(
				parent: AdapterView<*>?, view: View, position: Int, id: Long
			) {
				friendNameView.text = friends[position].name
				friendBirthdayView.text = friends[position].birthday
			}

			override fun onNothingSelected(adapterView: AdapterView<*>?) {
			}
		}
	}

	fun onClickAddFriend(view: View?) {
		startActivityForResult(Intent("AddFriendActivity"), 1)
	}

	fun onClickEdit(view: View?) {
		// Set field to match the selected friend
		val selectedFriend = spinner.selectedItem as Friend
		friendNameEdit.setText(selectedFriend.name)
		friendBirthdayEdit.setText(selectedFriend.birthday)
		// Show edit-fields and buttons
		setEditVisibility(true)
	}

	fun onClickSaveEdit(view: View?) {

		// Get new values
		val newName = friendNameEdit.text.toString()
		val newBirthday = friendBirthdayEdit.text.toString()

		// Update Friend object
		val friend = spinner.selectedItem as Friend
		friend.name = newName
		friend.birthday = newBirthday
		friendNameView.text = newName
		friendBirthdayView.text = newBirthday
		setEditVisibility(false)
	}

	fun onClickCancelEdit(view: View?) {
		setEditVisibility(false)
	}

	private fun setEditVisibility(visible: Boolean) {
		if (visible) {
			editLayout.visibility = View.VISIBLE
			editButtonLayout.visibility = View.VISIBLE
			editFriendButton.visibility = View.INVISIBLE
			addFriendButton.visibility = View.INVISIBLE
		} else {
			editLayout.visibility = View.INVISIBLE
			editButtonLayout.visibility = View.INVISIBLE
			editFriendButton.visibility = View.VISIBLE
			addFriendButton.visibility = View.VISIBLE
		}
	}

	public override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
		super.onActivityResult(requestCode, resultCode, data)
		if (resultCode == RESULT_OK) {
			val name = data!!.getStringExtra("new-name")
			val birthday = data.getStringExtra("new-birthday")
			friends.add(Friend(name!!, birthday!!))
		}
	}

	companion object {

		var friends = ArrayList<Friend>()
	}
}
