package ntnu.oving_03

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class AddFriendActivity : AppCompatActivity() {


	private lateinit var nameField: EditText
	private lateinit var birthdayField: EditText

	public override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		setContentView(R.layout.activity_add_friend)

		nameField = findViewById(R.id.edit_newFriendName)
		birthdayField = findViewById(R.id.edit_newFriendBirthday)
	}

	fun onClickSaveAddFriend(view: View?) {

		// Get input values
		val name = nameField.text.toString().trim()
		val birthday = birthdayField.text.toString().trim()

		// Validate input
		if (name == "" || birthday == "") {
			toast("Please fill both fields to add a new friend")
			return
		}
		// Send data as result back to main activity
		returnNewFriendData(name, birthday)
	}

	fun onClickCancelAddFriend(view: View?) {
		setResult(RESULT_CANCELED)
		finish()
	}

	fun returnNewFriendData(name: String, birthday: String) {
		val intent = Intent()
		intent.putExtra("new-name", name)
		intent.putExtra("new-birthday", birthday)
		setResult(RESULT_OK, intent)
		finish()
	}

	private fun toast(message: String) {
		Toast.makeText(this, message, Toast.LENGTH_LONG).show()
	}
}
